import { VIEW } from './view.js';
export class Input {
  constructor(canvas) {
    this.keys = {}; this.pressed = {}; this.mouse = { dx: 0, dy: 0, nx: 0, ny: 0, left: false, right: false, leftClick: false, rightClick: false }; this.wheel = 0; this.locked = false; this.canvas = canvas;
    window.addEventListener('keydown', e => { if (!this.keys[e.code]) this.pressed[e.code] = true; this.keys[e.code] = true; if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault(); });
    window.addEventListener('keyup', e => { this.keys[e.code] = false; });
    document.addEventListener('mousemove', e => { const r = canvas.getBoundingClientRect(); this.mouse.nx = ((e.clientX - r.left) / r.width) * 2 - 1; this.mouse.ny = -((e.clientY - r.top) / r.height) * 2 + 1; });
    canvas.parentElement.addEventListener('mousedown', e => { if (e.target.closest && e.target.closest('#minimap-wrap, #card-wrap, #dialog, #lore')) return; if (e.button === 0) { this.mouse.left = true; this.mouse.leftClick = true; } if (e.button === 2) { this.mouse.right = true; this.mouse.rightClick = true; } });
    document.addEventListener('mouseup', e => { if (e.button === 0) this.mouse.left = false; if (e.button === 2) this.mouse.right = false; });
    document.addEventListener('contextmenu', e => e.preventDefault());
    canvas.parentElement.addEventListener('wheel', e => { this.wheel += e.deltaY; e.preventDefault(); }, { passive: false });
  }
  // Pointer lock is not used in the top-down view; kept so callers stay simple.
  lock() {}
  unlock() {}
  down(k) { const m = { fwd: ['KeyW', 'ArrowUp'], back: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'], run: ['ShiftLeft', 'ShiftRight'] }; return (m[k] || []).some(c => this.keys[c]); }
  endFrame() { this.pressed = {}; this.mouse.dx = 0; this.mouse.dy = 0; this.mouse.leftClick = false; this.mouse.rightClick = false; this.wheel = 0; }
}
