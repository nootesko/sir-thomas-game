// Item catalogue. Prices are in moedas; selling pays half. Food heals slowly over time, potions heal at once.
export const SLOTS = ['espada', 'escudo', 'armadura', 'elmo', 'capa', 'botas', 'amuleto', 'anel'];
export const SLOT_NAMES = { espada: 'Espada', escudo: 'Escudo', armadura: 'Armadura', elmo: 'Elmo', capa: 'Capa', botas: 'Botas', amuleto: 'Amuleto', anel: 'Anel' };
const sword = (id, name, dano, price, lvl, rarity, extra = {}) => ({ id, slot: 'espada', rarity, icon: 'esp_' + id, name, lvl, stats: { dano }, price, sword: id, ...extra });
const armor = (id, name, defesa, price, lvl, rarity, extra = {}) => ({ id, slot: 'armadura', rarity, icon: 'arm_' + id, name, lvl, stats: { defesa }, price, ...extra });
const food = (id, name, vida, price, note) => ({ id, slot: null, rarity: 'comum', icon: id, name, lvl: 1, stats: { vida }, price, consumable: true, food: true, stack: true, note: note || 'Recupera vida aos poucos' });
const mat = (id, name, icon, price, note) => ({ id, slot: null, rarity: 'comum', icon, name, lvl: 1, stats: {}, price, material: true, stack: true, note });
export const ITEMS = {
  // ---- espadas ----
  real:         { id: 'real', slot: 'espada', rarity: 'comum', icon: 'espada', name: 'ESPADA REAL', lvl: 1, stats: { dano: 18 }, sword: 'real', price: 120 },
  ferro:        sword('ferro', 'ESPADA DE FERRO', 14, 60, 1, 'comum'),
  aco:          sword('aco', 'ESPADA DE AÇO', 22, 220, 3, 'raro'),
  fogo:         sword('fogo', 'ESPADA DE FOGO', 30, 700, 6, 'epico', { note: 'Queima o inimigo por alguns segundos', burn: true }),
  dente_dragao: sword('dente_dragao', 'DENTE DE DRAGÃO', 42, 2600, 10, 'lendario'),
  glacial:      { id: 'glacial', slot: 'espada', rarity: 'epico', icon: 'glacial', name: 'ESPADA GLACIAL', lvl: 3, stats: { dano: 24, frio: 10 }, sword: 'glacial', note: 'Congela inimigos pequenos', price: 500 },
  // ---- armaduras ----
  roupa:         { id: 'roupa', slot: 'armadura', rarity: 'comum', icon: 'armadura', name: 'ROUPA AZUL DO REINO', lvl: 1, stats: { defesa: 2 }, price: 20 },
  couro:         armor('couro', 'ARMADURA DE COURO', 4, 50, 1, 'comum'),
  latao:         armor('latao', 'ARMADURA DE LATÃO', 6, 140, 2, 'comum'),
  bronze:        armor('bronze', 'ARMADURA DE BRONZE', 8, 260, 3, 'raro'),
  cobre:         armor('cobre', 'ARMADURA DE COBRE', 10, 420, 4, 'raro'),
  prata:         armor('prata', 'ARMADURA DE PRATA', 13, 800, 6, 'epico'),
  ouro:          armor('ouro', 'ARMADURA DE OURO', 16, 1500, 8, 'epico'),
  escama_dragao: armor('escama_dragao', 'ESCAMAS DE DRAGÃO', 24, 4000, 10, 'lendario', { stats: { defesa: 24, frio: 20 } }),
  // ---- outros equipamentos ----
  reino:   { id: 'reino', slot: 'escudo', rarity: 'raro', icon: 'escudo', name: 'ESCUDO DO REINO', lvl: 1, stats: { defesa: 6 }, price: 200 },
  capa:    { id: 'capa', slot: 'capa', rarity: 'comum', icon: 'capa', name: 'CAPA DE LÃ', lvl: 1, stats: { frio: 35, defesa: 1 }, price: 40 },
  botas:   { id: 'botas', slot: 'botas', rarity: 'raro', icon: 'botas', name: 'BOTAS DO CAMINHANTE', lvl: 2, stats: { frio: 30, defesa: 2 }, price: 90 },
  elmo:    { id: 'elmo', slot: 'elmo', rarity: 'raro', icon: 'elmo', name: 'ELMO DO VALE', lvl: 2, stats: { defesa: 4, vida: 25 }, price: 150 },
  amuleto: { id: 'amuleto', slot: 'amuleto', rarity: 'epico', icon: 'amuleto', name: 'AMULETO DA CHAMA', lvl: 3, stats: { frio: 50, vida: 10 }, price: 400 },
  // ---- comida (cura lenta) ----
  pao:    food('pao', 'PÃO', 25, 8),
  queijo: food('queijo', 'QUEIJO', 20, 10),
  mel:    food('mel', 'MEL SILVESTRE', 35, 15),
  carne:  food('carne', 'CARNE ASSADA', 45, 20),
  sopa:   { id: 'sopa', slot: null, rarity: 'comum', icon: 'sopa', name: 'SOPA QUENTE', lvl: 1, stats: { vida: 50 }, consumable: true, food: true, warm: true, stack: true, price: 25, note: 'Recupera vida aos poucos e aquece' },
  // ---- poções (cura imediata) ----
  pocao_p: { id: 'pocao_p', slot: null, rarity: 'comum', icon: 'pocao_p', name: 'POÇÃO PEQUENA', lvl: 1, stats: { vida: 40 }, consumable: true, stack: true, price: 30, note: 'Cura na hora' },
  pocao_g: { id: 'pocao_g', slot: null, rarity: 'raro', icon: 'pocao_g', name: 'POÇÃO GRANDE', lvl: 3, stats: { vida: 120 }, consumable: true, stack: true, price: 90, note: 'Cura na hora' },
  // ---- materiais (drops para vender) ----
  pe_coelho:       mat('pe_coelho', 'PÉ DE COELHO', 'pe_coelho', 8, 'Dizem que dá sorte'),
  pele_lobo:       mat('pele_lobo', 'PELE DE LOBO', 'pele_lobo', 24, 'Quente e resistente'),
  ferrao_abelha:   mat('ferrao_abelha', 'FERRÃO DE ABELHA', 'ferrao_abelha', 12, 'Afiado como agulha'),
  escama_serpente: mat('escama_serpente', 'ESCAMA DE SERPENTE', 'escama_serpente', 16, 'Brilha em verde'),
  rabo_rato:       mat('rabo_rato', 'RABO DE RATO', 'rabo_rato', 4, 'Ninguém quer isso'),
  asa_barata:      mat('asa_barata', 'ASA DE BARATA', 'asa_barata', 2, 'Crocante'),
};
export const sellPrice = it => Math.max(1, Math.floor((it.price || 0) / 2));
// What each NPC sells. Every shop buys any item that has a price.
export const SHOPS = {
  ferreiro:   { title: 'Forja do Bruno', items: ['ferro', 'aco', 'fogo', 'dente_dragao', 'couro', 'latao', 'bronze', 'cobre', 'prata', 'ouro', 'escama_dragao'] },
  cozinheira: { title: 'Cozinha da Dona Rosa', items: ['pao', 'queijo', 'mel', 'carne', 'sopa'] },
  mercador:   { title: 'Mercador Gaspar', items: ['pocao_p', 'pocao_g', 'pao', 'queijo', 'capa', 'botas'] },
};
