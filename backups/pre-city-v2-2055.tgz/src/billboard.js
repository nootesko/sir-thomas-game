// Camera-facing pixel-art sprites (y-axis billboards). Static sets use InstancedMesh; dynamic ones are single meshes.
import * as THREE from 'three';
import { VIEW } from './view.js';
const geo = new THREE.PlaneGeometry(1, 1); geo.translate(0, 0.5, 0);
const matCache = new Map();
export function spriteMaterial(src, opts = {}) {
  const k = src; if (matCache.has(k)) return matCache.get(k);
  const t = new THREE.Texture(src); t.needsUpdate = true; t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestMipmapLinearFilter; t.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.MeshBasicMaterial({ map: t, transparent: true, alphaTest: 0.5, side: THREE.DoubleSide, depthWrite: true, fog: opts.fog !== false });
  matCache.set(k, m); return m;
}
export function tintAll(color) { for (const m of matCache.values()) m.color.set(color); }
export class BillboardSet {
  constructor(scene, src, max) { this.mesh = new THREE.InstancedMesh(geo, spriteMaterial(src), max); this.mesh.count = 0; this.mesh.frustumCulled = false; this.items = []; scene.add(this.mesh); this.m = new THREE.Matrix4(); this.q = new THREE.Quaternion(); this.p = new THREE.Vector3(); this.s = new THREE.Vector3(); }
  add(x, z, w, h, y = 0) { this.items.push({ x, y, z, w, h }); }
  finalize() { this.mesh.count = this.items.length; this.face(0); }
  face(yaw = VIEW.yaw, tilt = VIEW.tilt) { this.q.setFromEuler(new THREE.Euler(tilt, yaw, 0, 'YXZ')); for (let i = 0; i < this.items.length; i++) { const it = this.items[i]; this.p.set(it.x, it.y, it.z); this.s.set(it.w, it.h, 1); this.m.compose(this.p, this.q, this.s); this.mesh.setMatrixAt(i, this.m); } this.mesh.instanceMatrix.needsUpdate = true; }
}
export function makeBillboard(src, w, h) { const m = new THREE.Mesh(geo, spriteMaterial(src)); m.scale.set(w, h, 1); m.userData.w = w; m.userData.h = h; return m; }
export function setBillboardImage(mesh, src) { mesh.material = spriteMaterial(src); }
// Orient a dynamic sprite toward the fixed camera (keeps any z-roll the caller sets afterwards).
export function faceView(mesh) { mesh.rotation.order = 'YXZ'; mesh.rotation.x = VIEW.tilt; mesh.rotation.y = VIEW.yaw; }
