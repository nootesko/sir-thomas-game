// The world: a medieval city inside golden walls, the Light tower, fields, river, road and the frozen forest.
import * as THREE from 'three';
import { TileMap, T } from './tilemap.js';
import { Assets } from './assets.js';
import * as PX from './pixel.js';
import * as S from './sprites.js';
import { BillboardSet } from './billboard.js';

let seed = 4242; const rng = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
const R = (a, b) => a + rng() * (b - a);
export const WALL = 90, GATE_HALF = 5, WORLD = 360;
// Sewer: a walled dungeon in the far south-west corner, reached through a grate in the city streets.
export const SEWER = { x0: -335, x1: -195, z0: 195, z1: 335, entry: [-205, 205], grate: [-36, 36] };

// quick placeholder shapes for props whose PNG is still missing
function ph(w, h, fill, line = '#2a1a0a') { const [c, x] = S.canvas(w, h); x.fillStyle = line; x.fillRect(0, 0, w, h); x.fillStyle = fill; x.fillRect(1, 1, w - 2, h - 2); return c; }
export class City {
  constructor(scene) {
    this.scene = scene; this.colliders = []; this.buildings = []; this.roads = []; this.plazas = []; this.trees = []; this.props = []; this.lamps = []; this.scorch = [];
    this.sets = {}; this.night = false; this.winter = false;
    this.buildTextures(); this.buildGround(); this.buildWalls(); this.buildTower(); this.buildCity(); this.buildOutside(); this.buildSewer(); this.finalizeSets(); this.buildTiles();
  }
  // ---------- materials ----------
  buildTextures() {
    const T = (name, fb, rep) => Assets.texture(name, fb, { repeat: rep });
    this.tex = {
      gold: T('tex_goldstone_wall', PX.texGoldstone(), 1), cobble: T('tex_cobblestone', PX.texCobble(), 1), grass: T('tex_grass', PX.texGrass(), 1), snow: T('tex_snow', PX.texSnow(), 1),
      dirt: T('tex_dirt_path', PX.texDirt(), 1), roof: T('tex_roof_red', PX.texRoof(), 1), plaster: T('tex_plaster_timber', PX.texPlaster(), 1), planks: T('tex_wood_planks', PX.texPlanks(), 1), water: T('tex_water', PX.texWater(), 1), ice: T(null, PX.texIce(), 1), stone: T(null, PX.texStoneGray(), 1), sewer: T('tex_sewer_stone', PX.texStoneGray(), 1), sewage: T('tex_sewer_water', PX.texWater(), 1),
    };
    this.mat = {};
    const mk = (tex, rx, ry, extra = {}) => { const t = tex.clone(); t.needsUpdate = true; t.repeat.set(rx, ry); return new THREE.MeshLambertMaterial({ map: t, ...extra }); };
    this.mk = mk;
    this.groundMat = mk(this.tex.grass, 180, 180); this.cobbleMat = mk(this.tex.cobble, 60, 60); this.dirtMat = mk(this.tex.dirt, 1, 1); this.waterMat = mk(this.tex.water, 6, 60, { transparent: true, opacity: 0.9 });
  }
  box(w, h, d, mat, x, y, z) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; this.scene.add(m); return m; }
  addBox(cx, cz, w, d) { this.colliders.push({ type: 'box', minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2 }); }
  addCircle(x, z, r) { this.colliders.push({ type: 'circle', x, z, r }); }
  set(name, src, max, w, h) { const s = new BillboardSet(this.scene, src, max); s.w = w; s.h = h; this.sets[name] = s; return s; }
  finalizeSets() { for (const s of Object.values(this.sets)) s.finalize(); }
  faceAll() { for (const s of Object.values(this.sets)) s.face(); }

  // ---------- ground ----------
  buildGround() {
    // roads outside: east road to the forest gate, south road
    const road = (x, z, w, d) => this.roads.push({ x, z, w, d });
    road(WALL + 95, 0, 190, 9); road(WALL + 110, 30, 9, 70); road(0, WALL + 45, 9, 90);
    this.streets = [{ x: 0, z: 0, w: WALL * 2, d: 12 }, { x: 0, z: 0, w: 12, d: WALL * 2 }, { x: 0, z: 36, w: WALL * 2, d: 6 }, { x: 0, z: -36, w: WALL * 2, d: 6 }, { x: 36, z: 0, w: 6, d: WALL * 2 }, { x: -36, z: 0, w: 6, d: WALL * 2 }, { x: 0, z: 68, w: WALL * 2, d: 6 }, { x: 0, z: -68, w: WALL * 2, d: 6 }, { x: 68, z: 0, w: 6, d: WALL * 2 }, { x: -68, z: 0, w: 6, d: WALL * 2 }];
    // river (west)
    this.colliders.push({ type: 'box', minX: -163, maxX: -137, minZ: -WORLD, maxZ: WORLD });
    // plazas (slightly lighter cobble)
    const plaza = (x, z, r) => this.plazas.push({ x, z, r });
    plaza(0, 0, 17); plaza(0, -44, 13);
    // world edge
    this.colliders.push({ type: 'box', minX: -WORLD - 10, maxX: -WORLD, minZ: -WORLD, maxZ: WORLD }, { type: 'box', minX: WORLD, maxX: WORLD + 10, minZ: -WORLD, maxZ: WORLD }, { type: 'box', minX: -WORLD, maxX: WORLD, minZ: -WORLD - 10, maxZ: -WORLD }, { type: 'box', minX: -WORLD, maxX: WORLD, minZ: WORLD, maxZ: WORLD + 10 });
  }
  // ---------- walls ----------
  wallSeg(cx, cz, w, d, h = 9) {
    const m = this.box(w, h, d, this.mk(this.tex.gold, Math.max(w, d) / 4, h / 4), cx, h / 2, cz); this.addBox(cx, cz, w, d);
    const along = w > d, len = along ? w : d; const bm = this.mk(this.tex.gold, 1, 1);
    for (let i = 0; i < Math.floor(len / 3); i++) { const off = -len / 2 + 1.5 + i * 3; this.box(along ? 1.5 : w + 0.4, 1.4, along ? d + 0.4 : 1.5, bm, along ? cx + off : cx, h + 0.7, along ? cz : cz + off); }
    const walk = this.box(along ? w : w + 1, 0.3, along ? d + 1 : d, this.mk(this.tex.stone, len / 4, 1), cx, h + 0.15, cz);
    return m;
  }
  tower(cx, cz, r, h, roofColor = 0x2b5fc7) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.06, h, 12), this.mk(this.tex.gold, 6, h / 4)); m.position.set(cx, h / 2, cz); m.castShadow = true; m.receiveShadow = true; this.scene.add(m);
    const cone = new THREE.Mesh(new THREE.ConeGeometry(r * 1.25, r * 1.5, 12), new THREE.MeshLambertMaterial({ color: roofColor })); cone.position.set(cx, h + r * 0.75, cz); cone.castShadow = true; this.scene.add(cone);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.15, r * 1.15, 1.2, 12), this.mk(this.tex.gold, 6, 1)); ring.position.set(cx, h - 0.3, cz); this.scene.add(ring);
    this.addCircle(cx, cz, r + 0.2); this.buildings.push({ x: cx, z: cz, w: r * 2, d: r * 2, kind: 'tower' }); return m;
  }
  buildWalls() {
    const W = WALL, T = 2.4;
    this.wallSeg(-W, 0, T, W * 2); this.wallSeg(0, -W, W * 2, T);
    const segLen = W - GATE_HALF; this.wallSeg(W, -(GATE_HALF + segLen / 2), T, segLen); this.wallSeg(W, GATE_HALF + segLen / 2, T, segLen);
    this.wallSeg(-(GATE_HALF + segLen / 2), W, segLen, T); this.wallSeg(GATE_HALF + segLen / 2, W, segLen, T);   // south wall with a gate
    this.box(T + 1.5, 2.5, GATE_HALF * 2 + 1, this.mk(this.tex.gold, 3, 1), W, 9 - 1.25 + 1.2, 0); this.box(GATE_HALF * 2 + 1, 2.5, T + 1.5, this.mk(this.tex.gold, 3, 1), 0, 9 - 1.25 + 1.2, W);
    [[-W, -W], [W, -W], [-W, W], [W, W]].forEach(([x, z]) => this.tower(x, z, 5, 14));
    this.tower(W, -(GATE_HALF + 4.5), 4, 13); this.tower(W, GATE_HALF + 4.5, 4, 13); this.tower(-(GATE_HALF + 4.5), W, 4, 13); this.tower(GATE_HALF + 4.5, W, 4, 13);
    this.southGate = new THREE.Vector3(0, 0, W);
    // banners on the gate towers and along the east wall
    const ban = this.set('banner', Assets.src('prop_banner', PX.propBanner()), 40, 1.6, 4);
    ban.add(W - 5.2, -(GATE_HALF + 4.5), 1.6, 4, 8); ban.add(W - 5.2, GATE_HALF + 4.5, 1.6, 4, 8);
    for (let z = -80; z <= 80; z += 20) if (Math.abs(z) > 10) ban.add(W - 1.6, z, 1.4, 3.5, 4.5);
    for (let x = -80; x <= 80; x += 20) ban.add(x, -W + 1.6, 1.4, 3.5, 4.5);
    for (let x = -80; x <= 80; x += 20) if (Math.abs(x) > 10) ban.add(x, W - 1.6, 1.4, 3.5, 4.5);
  }
  // ---------- the Light tower ----------
  buildTower() {
    const x = 0, z = -60, r = 6, h = 38;
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.08, h, 14), this.mk(this.tex.gold, 8, h / 4)); m.position.set(x, h / 2, z); m.castShadow = true; this.scene.add(m);
    for (let i = 0; i < 3; i++) { const ring = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.12, r * 1.12, 0.8, 14), this.mk(this.tex.gold, 8, 1)); ring.position.set(x, 10 + i * 12, z); this.scene.add(ring); }
    const top = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.3, r * 1.3, 1.4, 14), this.mk(this.tex.gold, 8, 1)); top.position.set(x, h + 0.7, z); this.scene.add(top);
    for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; const b = this.box(1.2, 1.4, 1.2, this.mk(this.tex.gold, 1, 1), x + Math.cos(a) * r * 1.2, h + 2.1, z + Math.sin(a) * r * 1.2); }
    const ped = this.box(1.6, 2.2, 1.6, this.mk(this.tex.stone, 1, 1), x, h + 2.5, z);
    this.lightPos = new THREE.Vector3(x, h + 4.6, z);
    this.lightMesh = new THREE.Mesh(new THREE.OctahedronGeometry(1.0, 0), new THREE.MeshBasicMaterial({ color: 0xffe066 })); this.lightMesh.position.copy(this.lightPos); this.scene.add(this.lightMesh);
    const glowTex = new THREE.CanvasTexture(PX.propGemGlow()); this.lightGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: 0xffd23a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })); this.lightGlow.scale.set(12, 12, 1); this.lightGlow.position.copy(this.lightPos); this.scene.add(this.lightGlow);
    this.lightBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.9, 90, 8, 1, true), new THREE.MeshBasicMaterial({ color: 0xffe066, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); this.lightBeam.position.set(x, h + 50, z); this.scene.add(this.lightBeam);
    this.lightPoint = new THREE.PointLight(0xffd23a, 120, 90, 1.5); this.lightPoint.position.copy(this.lightPos); this.scene.add(this.lightPoint);
    this.addCircle(x, z, r + 0.3); this.buildings.push({ x, z, w: r * 2, d: r * 2, kind: 'light' });
    // Praça da Luz: a golden ring on the ground marks the fight zone, statues and banners
    const ring = new THREE.Mesh(new THREE.RingGeometry(7, 8, 32), new THREE.MeshBasicMaterial({ color: 0xf6c12e, transparent: true, opacity: 0.7 })); ring.rotation.x = -Math.PI / 2; ring.position.set(0, 0.07, -44); this.scene.add(ring); this.altar = new THREE.Vector3(0, 0, -44);
    const st = this.set('statue', Assets.src('prop_statue_knight', PX.propStatue()), 8, 2.2, 4.4);
    [[-10, -52], [10, -52], [-14, -8], [14, -8]].forEach(([sx, sz]) => { st.add(sx, sz, 2.2, 4.4); this.addCircle(sx, sz, 0.9); });
  }
  // ---------- the city ----------
  building(cx, cz, w, d, h, kind = 'house', face = 'auto') {
    const g = new THREE.Group();
    const wallMat = kind === 'chapel' || kind === 'castle' ? this.mk(this.tex.stone, w / 4, h / 4) : kind === 'tavern' || kind === 'smithy' ? this.mk(this.tex.planks, w / 3, h / 3) : this.mk(this.tex.plaster, w / 5, h / 5);
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat); body.position.y = h / 2; body.castShadow = true; body.receiveShadow = true; g.add(body);
    const roofMat = this.mk(this.tex.roof, 3, 3); const roofH = kind === 'chapel' ? h * 1.2 : kind === 'castle' ? 4 : Math.max(2.5, Math.min(w, d) * 0.45);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(1, 1, 4), kind === 'chapel' || kind === 'castle' ? new THREE.MeshLambertMaterial({ color: 0x2b5fc7 }) : roofMat); roof.rotation.y = Math.PI / 4; roof.scale.set(w * 0.78, roofH, d * 0.78); roof.position.y = h + roofH / 2; roof.castShadow = true; g.add(roof);
    // which side faces the street: toward the nearest axis
    const toX = Math.abs(cx) < Math.abs(cz); // closer to the x=0 street? then door faces x=0 direction
    let dir; if (face !== 'auto') dir = face; else dir = toX ? (cx > 0 ? 'w' : 'e') : (cz > 0 ? 'n' : 's');
    const place = (ox, oy, oz, bw, bh, bd, color, emissive) => { const m = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), new THREE.MeshLambertMaterial({ color, emissive: emissive || 0x000000 })); m.position.set(ox, oy, oz); g.add(m); return m; };
    const off = { n: [0, -d / 2 - 0.08], s: [0, d / 2 + 0.08], e: [w / 2 + 0.08, 0], w: [-w / 2 - 0.08, 0] }[dir]; const horiz = dir === 'n' || dir === 's';
    place(off[0], 1.2, off[1], horiz ? 1.4 : 0.16, 2.4, horiz ? 0.16 : 1.4, 0x5a3a1a);
    const winMat = this.winMat = this.winMat || new THREE.MeshLambertMaterial({ color: 0x9ad0ff, emissive: 0x224466 });
    for (const s of [-1, 1]) { const wm = new THREE.Mesh(new THREE.BoxGeometry(horiz ? 1.0 : 0.16, 1.0, horiz ? 0.16 : 1.0), winMat); wm.position.set(off[0] + (horiz ? s * w * 0.3 : 0), h * 0.6, off[1] + (horiz ? 0 : s * d * 0.3)); g.add(wm); }
    if (kind === 'house' && rng() < 0.6) place(w * 0.25, h + roofH * 0.6, -d * 0.2, 1, roofH * 0.9, 1, 0x7a4a22);
    if (kind === 'chapel') { const spire = new THREE.Mesh(new THREE.ConeGeometry(1.6, 7, 6), new THREE.MeshLambertMaterial({ color: 0x2b5fc7 })); spire.position.set(0, h + roofH + 3, 0); g.add(spire); const cross = place(0, h + roofH + 7, 0, 0.3, 1.6, 0.3, 0xf6c12e); place(0, h + roofH + 7.3, 0, 1.0, 0.3, 0.3, 0xf6c12e); }
    if (kind === 'tavern') { place(off[0] + (horiz ? 2.6 : 0), 3.2, off[1] + (horiz ? 0 : 2.6), horiz ? 1.6 : 0.2, 1.2, horiz ? 0.2 : 1.6, 0xd9a441); }
    g.position.set(cx, 0, cz); this.scene.add(g); this.addBox(cx, cz, w, d); this.buildings.push({ x: cx, z: cz, w, d, kind, dir });
    this.registerFade(g, cx, cz, w, d, h + roofH);
    return g;
  }
  buildDistricts() {
    const W = WALL;
    // ---- Castelo Real (north-west): keep, four towers, low courtyard wall open to the south ----
    const kx = -68, kz = -76; this.building(kx, kz, 26, 14, 12, 'castle', 's');
    [[kx - 13, kz - 7], [kx + 13, kz - 7], [kx - 13, kz + 7], [kx + 13, kz + 7]].forEach(([x, z]) => this.tower(x, z, 3.2, 17, 0x2b5fc7));
    const cw = this.mk(this.tex.gold, 8, 1); const yard = (x, z, w, d) => { this.box(w, 2.6, d, cw, x, 1.3, z); this.addBox(x, z, w, d); };
    yard(kx - 18, kz + 5, 1.2, 30); yard(kx + 18, kz + 5, 1.2, 30); yard(kx - 10, kz + 20, 15, 1.2); yard(kx + 10, kz + 20, 15, 1.2);
    this.castleGate = new THREE.Vector3(kx, 0, kz + 20); this.throne = new THREE.Vector3(kx, 0, kz + 9.5);
    const ban = this.sets.banner; ban.add(kx - 6, kz + 7.6, 1.6, 4, 7); ban.add(kx + 6, kz + 7.6, 1.6, 4, 7); ban.add(kx - 18.9, kz + 20, 1.4, 3.5, 3.5); ban.add(kx + 18.9, kz + 20, 1.4, 3.5, 3.5);
    const flowers = this.set('flowers', Assets.src('prop_flowers', ph(16, 8, '#e04060', '#2a6a2a')), 40, 2.2, 1.1); [[kx - 8, kz + 12], [kx + 8, kz + 12], [kx - 8, kz + 16], [kx + 8, kz + 16]].forEach(([x, z]) => flowers.add(x, z, 2.2, 1.1));
    this.buildings.push({ x: kx, z: kz + 6, w: 38, d: 30, kind: 'castleyard' });
    // ---- Jardins (south-east): hedges, flower beds, benches, oaks ----
    const bench = this.set('bench', Assets.src('prop_bench', ph(16, 7, '#8a5a2e')), 20, 2.2, 1.0), fence = this.set('fence', Assets.src('prop_fence', ph(20, 8, '#a06a3a')), 120, 3.2, 1.3);
    for (let i = 0; i < 8; i++) { flowers.add(58 + (i % 4) * 8, 58 + Math.floor(i / 4) * 16, 2.2, 1.1); }
    [[62, 66], [70, 66], [78, 66], [62, 82], [70, 82], [78, 82]].forEach(([x, z]) => { bench.add(x, z, 2.2, 1.0); this.addBox(x, z, 2, 0.8); });
    [[54, 54], [86, 54], [54, 86], [86, 86], [70, 74]].forEach(([x, z]) => { this.sets.oak.add(x, z, 6, 7.5); this.addCircle(x, z, 0.7); this.trees.push({ x, z, oak: true }); });
    for (let x = 52; x <= 88; x += 3.2) { if (Math.abs(x - 70) < 3) continue; fence.add(x, 50.5, 3.2, 1.3); fence.add(x, 89.5, 3.2, 1.3); } this.addBox(60, 50.5, 16, 0.4); this.addBox(80, 50.5, 16, 0.4);
    // ---- Campo de Treino (north-east): dummies and fences near the barracks ----
    const dummy = this.set('dummy', Assets.src('prop_training_dummy', ph(10, 16, '#c9a84a')), 12, 1.4, 2.2);
    [[58, -62], [64, -62], [70, -62], [58, -70], [64, -70], [70, -70]].forEach(([x, z]) => { dummy.add(x, z, 1.4, 2.2); this.addCircle(x, z, 0.5); });
    for (let x = 52; x <= 76; x += 3.2) { fence.add(x, -56.5, 3.2, 1.3); fence.add(x, -77.5, 3.2, 1.3); } this.addBox(64, -56.5, 26, 0.4); this.addBox(64, -77.5, 26, 0.4);
    const crates = this.set('crates', Assets.src('prop_crates', ph(14, 12, '#8a5a2e')), 20, 2.4, 2.0); [[80, -64], [80, -68], [78, -72]].forEach(([x, z]) => { crates.add(x, z, 2.4, 2.0); this.addBox(x, z, 2, 1.6); });
    // ---- Hortas (south-west): fenced plots with hay and crates ----
    for (const [px, pz] of [[-80, 56], [-62, 56], [-80, 78], [-62, 78]]) { for (let x = px - 7; x <= px + 7; x += 3.5) { fence.add(x, pz - 6, 3.2, 1.3); fence.add(x, pz + 6, 3.2, 1.3); } this.addBox(px, pz - 6, 15, 0.4); this.addBox(px, pz + 6, 15, 0.4); for (let i = 0; i < 6; i++) this.sets.bush.add(px - 5 + (i % 3) * 5, pz - 2.5 + Math.floor(i / 3) * 5, 1.8, 1.2); }
    crates.add(-70, 66, 2.4, 2.0); this.addBox(-70, 66, 2, 1.6); this.sets.cart.add(-52, 66, 4, 2.7); this.addBox(-52, 66, 3.6, 2);
    // lamps along the outer ring street
    for (let v = -80; v <= 80; v += 16) for (const s of [-1, 1]) { this.sets.lamp.add(v, s * 71.5, 1.3, 4); this.lamps.push({ x: v, z: s * 71.5 }); this.sets.lamp.add(s * 71.5, v, 1.3, 4); this.lamps.push({ x: s * 71.5, z: v }); }
    this.sets.sign.add(6, WALL - 8, 1.8, 2.4); this.sets.sign.add(0, WALL + 12, 1.8, 2.4);
  }
  buildCity() {
    // special buildings (fixed)
    this.building(16, -16, 16, 12, 7, 'tavern', 's'); this.building(-24, -28, 12, 20, 9, 'chapel', 'e'); this.building(26, 13, 12, 10, 5, 'smithy', 'n'); this.building(-30, 14, 12, 10, 5, 'bakery', 'n'); this.building(56, 16, 14, 10, 6, 'barracks', 'w');
    // Thomas's house: three walls + roof, open to the north, bed inside
    const hx = -18, hz = 56; const pm = this.mk(this.tex.plaster, 2, 1);
    this.box(10, 5, 0.4, pm, hx, 2.5, hz + 4); this.box(0.4, 5, 8, pm, hx - 5, 2.5, hz); this.box(0.4, 5, 8, pm, hx + 5, 2.5, hz);
    this.addBox(hx, hz + 4, 10, 0.4); this.addBox(hx - 5, hz, 0.4, 8); this.addBox(hx + 5, hz, 0.4, 8);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(1, 1, 4), this.mk(this.tex.roof, 3, 3)); roof.rotation.y = Math.PI / 4; roof.scale.set(8.5, 3.5, 7); roof.position.set(hx, 5 + 1.75, hz); this.scene.add(roof); this.homeRoof = roof; this.homeBox = { x: hx, z: hz, w: 10, d: 8 };
    this.box(2.2, 0.6, 3.2, new THREE.MeshLambertMaterial({ color: 0x8a5a2e }), hx - 3, 0.3, hz + 1.5); this.box(2.1, 0.3, 2.4, new THREE.MeshLambertMaterial({ color: 0x2b5fc7 }), hx - 3, 0.7, hz + 1.9); this.box(1.8, 0.3, 0.7, new THREE.MeshLambertMaterial({ color: 0xf4efe0 }), hx - 3, 0.7, hz + 0.4);
    this.addBox(hx - 3, hz + 1.5, 2.2, 3.2); this.bedPos = new THREE.Vector3(hx - 3, 0, hz + 1.5); this.buildings.push({ x: hx, z: hz, w: 10, d: 8, kind: 'home', dir: 'n' });
    const shelf = this.box(2.5, 0.2, 0.6, new THREE.MeshLambertMaterial({ color: 0x6b4423 }), hx + 2.5, 2, hz + 3.5);
    // generated blocks (the castle yard is reserved first)
    this.addBox(-68, -70, 40, 44);
    const ranges = [[8, 32], [40, 62], [74, 86]];
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (const [ax, bx] of ranges) for (const [az, bz] of ranges) {
      const n = 2 + Math.floor(rng() * 2); let placed = 0, tries = 0;
      while (placed < n && tries++ < 20) {
        const w = R(7, 12), d = R(7, 12), h = R(4.5, 7); const cx = sx * R(ax + w / 2 + 1, bx - w / 2 - 1), cz = sz * R(az + d / 2 + 1, bz - d / 2 - 1);
        const minX = cx - w / 2 - 2, maxX = cx + w / 2 + 2, minZ = cz - d / 2 - 2, maxZ = cz + d / 2 + 2;
        let ok = true; for (const c of this.colliders) if (c.type === 'box' && !(maxX < c.minX || minX > c.maxX || maxZ < c.minZ || minZ > c.maxZ)) { ok = false; break; } else if (c.type === 'circle' && Math.hypot(Math.max(minX, Math.min(c.x, maxX)) - c.x, Math.max(minZ, Math.min(c.z, maxZ)) - c.z) < c.r + 1) { ok = false; break; }
        if (Math.hypot(cx, cz) < 22 || Math.hypot(cx, cz + 44) < 18 || (cx > 50 && cz > 48) || (cx > 50 && cz < -54) || (cx < -50 && cz > 48)) ok = false;
        if (!ok) continue; this.building(cx, cz, w, d, h, 'house'); placed++;
      }
    }
    this.colliders = this.colliders.filter(c => !(c.type === 'box' && c.minX === -88 && c.maxX === -48 && c.minZ === -92));
    // props: fountain, oaks, lamps, stalls, barrels, carts, bushes, well, signpost
    const fountain = this.set('fountain', Assets.src('prop_fountain', PX.propFountain()), 2, 5, 4.2); fountain.add(0, 0, 5, 4.2); this.addCircle(0, 0, 2.6);
    const oak = this.set('oak', Assets.src('sprite_tree_oak', PX.propOak(false)), 60, 6, 7.5); [[-13, -13], [13, -13], [-13, 13], [13, 13], [-50, -50], [50, -50], [-50, 50], [50, 50], [-36, -8], [36, 8], [-8, 36], [8, -36]].forEach(([x, z]) => { oak.add(x, z, 6, 7.5); this.addCircle(x, z, 0.7); this.trees.push({ x, z, oak: true }); });
    const lamp = this.set('lamp', Assets.src('prop_lamp_post', PX.propLamp(true)), 80, 1.3, 4);
    for (let x = 22; x <= 62; x += 13) for (const s of [-1, 1]) { lamp.add(x, s * 6.3, 1.3, 4); this.lamps.push({ x, z: s * 6.3 }); }
    for (let z = -20; z >= -34; z -= 14) for (const s of [-1, 1]) { lamp.add(s * 6.3, z, 1.3, 4); this.lamps.push({ x: s * 6.3, z }); }
    for (let z = 22; z <= 48; z += 13) for (const s of [-1, 1]) { lamp.add(s * 6.3, z, 1.3, 4); this.lamps.push({ x: s * 6.3, z }); }
    for (let x = -22; x >= -62; x -= 13) for (const s of [-1, 1]) { lamp.add(x, s * 6.3, 1.3, 4); this.lamps.push({ x, z: s * 6.3 }); }
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; lamp.add(Math.cos(a) * 15.5, Math.sin(a) * 15.5, 1.3, 4); this.lamps.push({ x: Math.cos(a) * 15.5, z: Math.sin(a) * 15.5 }); }
    const stallA = this.set('stallA', Assets.src('prop_market_stall', PX.propStall('#d93b3b')), 12, 4.2, 3.5), stallB = this.set('stallB', Assets.src('prop_market_stall', PX.propStall('#2b5fc7')), 12, 4.2, 3.5);
    for (let i = 0; i < 6; i++) { const x = -22 - i * 7, z = i % 2 ? 7.5 : -7.5; (i % 2 ? stallA : stallB).add(x, z, 4.2, 3.5); this.addBox(x, z, 4, 2.5); }
    stallA.add(-12, 11, 4.2, 3.5); this.addBox(-12, 11, 4, 2.5); stallB.add(12, 11, 4.2, 3.5); this.addBox(12, 11, 4, 2.5);
    const barrel = this.set('barrel', Assets.src('prop_barrel_crate', PX.propBarrel()), 30, 2.4, 1.8); [[20, 7.2], [-20, -7.2], [60, -8], [34, -7.4], [-7, 20], [7, -20], [-40, 8], [26, 7.5]].forEach(([x, z]) => { barrel.add(x, z, 2.4, 1.8); this.addBox(x, z, 2, 1.2); });
    const cart = this.set('cart', Assets.src('prop_hay_cart', PX.propCart()), 4, 4, 2.7); cart.add(60, 7.5, 4, 2.7); this.addBox(60, 7.5, 3.6, 2); cart.add(WALL + 8, -7, 4, 2.7); this.addBox(WALL + 8, -7, 3.6, 2);
    const bush = this.set('bush', Assets.src('prop_bush', PX.propBush()), 60, 1.8, 1.2); for (let i = 0; i < 30; i++) { const a = rng() * Math.PI * 2, r = 14 + rng() * 4; if (Math.abs(Math.sin(a)) < 0.3 || Math.abs(Math.cos(a)) < 0.3) continue; bush.add(Math.cos(a) * r, Math.sin(a) * r, 1.8, 1.2); }
    const well = this.set('well', Assets.src('prop_well', S.WELL), 2, 2.4, 2.4); well.add(-46, -12, 2.4, 2.4); this.addCircle(-46, -12, 1.2);
    const sign = this.set('sign', Assets.src('prop_signpost', PX.propSign()), 4, 1.8, 2.4); sign.add(WALL + 10, 6, 1.8, 2.4); sign.add(WALL + 110, 26, 1.8, 2.4);
    // forge in front of the smithy
    this.box(2.2, 1.6, 1.6, this.mk(this.tex.stone, 1, 1), 22, 0.8, 6.5); this.box(1.4, 0.3, 1.0, new THREE.MeshLambertMaterial({ color: 0xff6a00, emissive: 0xff4400 }), 22, 1.7, 6.5); this.addBox(22, 6.5, 2.2, 1.6);
    this.box(1.2, 0.5, 0.5, new THREE.MeshLambertMaterial({ color: 0x3a3a40 }), 25, 0.9, 6.5); this.box(0.6, 0.7, 0.6, new THREE.MeshLambertMaterial({ color: 0x5a3a1a }), 25, 0.35, 6.5); this.addBox(25, 6.5, 1.2, 0.6);
    this.forgeLight = new THREE.PointLight(0xff6a00, 12, 14); this.forgeLight.position.set(22, 2.2, 6.5); this.scene.add(this.forgeLight); this.forgePos = new THREE.Vector3(25, 0, 6.5);
    // plaza lights (night)
    this.plazaLights = []; [[12, 12], [-12, 12], [12, -12], [-12, -12], [0, -40], [-68, -62]].forEach(([x, z]) => { const l = new THREE.PointLight(0xffb040, 0, 30, 1.2); l.position.set(x, 4, z); this.scene.add(l); this.plazaLights.push(l); });
    this.buildDistricts();
  }
  // ---------- outside ----------
  buildOutside() {
    const pine = this.set('pine', Assets.src('sprite_tree_pine', S.TREES.summer), 1400, 5, 8), pineW = this.set('pineW', Assets.src('sprite_tree_pine_snow', S.TREES.winter), 1400, 5, 8);
    const big = this.set('big', Assets.src('sprite_tree_pine', S.TREES.bigSummer), 60, 9, 14), bigW = this.set('bigW', Assets.src('sprite_tree_pine_snow', S.TREES.bigWinter), 60, 9, 14);
    const rock = this.set('rock', Assets.src('prop_rock', S.ROCKS.summer), 200, 2.6, 1.6);
    const add = (x, z, isBig = false) => { const s = R(0.85, 1.3); if (isBig) { big.add(x, z, 9 * s, 14 * s); bigW.add(x, z, 9 * s, 14 * s); this.addCircle(x, z, 1.2); } else { pine.add(x, z, 5 * s, 8 * s); pineW.add(x, z, 5 * s, 8 * s); this.addCircle(x, z, 0.6); } this.trees.push({ x, z }); };
    const blocked = (x, z) => (Math.abs(x) < WALL + 12 && Math.abs(z) < WALL + 12) || (x > WALL && Math.abs(z) < 9) || (x > WALL + 100 && x < WALL + 120 && z > -8 && z < 70) || Math.abs(x + 150) < 20 || (x < SEWER.x1 + 8 && z > SEWER.z0 - 8);
    for (let i = 0; i < 700; i++) { const x = R(-WORLD, WORLD), z = R(-WORLD, WORLD); if (blocked(x, z)) continue; add(x, z, rng() < 0.08); }
    for (let i = 0; i < 700; i++) { const x = R(WALL + 180, WORLD), z = R(-WORLD, WORLD); if (blocked(x, z)) continue; add(x, z, rng() < 0.15); }
    for (let i = 0; i < 140; i++) { const x = R(-WORLD, WORLD), z = R(-WORLD, WORLD); if (blocked(x, z)) continue; rock.add(x, z, 2.6, 1.6); this.addCircle(x, z, 1.0); }
    // forest gate: two giant trees flanking the road
    this.forestGate = new THREE.Vector3(WALL + 185, 0, 0); add(WALL + 185, -9, true); add(WALL + 185, 9, true);
    // scorch marks along the road (visible in winter)
    const sc = this.set('scorch', Assets.src('prop_scorch_mark', PX.propScorch()), 60, 3, 3);
    this.scorchGroup = new THREE.Group(); this.scene.add(this.scorchGroup); const scMat = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(Assets.src('prop_scorch_mark', PX.propScorch())), transparent: true, depthWrite: false });
    scMat.map.magFilter = THREE.NearestFilter; scMat.map.colorSpace = THREE.SRGBColorSpace;
    for (let x = WALL + 6; x < WALL + 182; x += 6) { const z = Math.sin(x * 0.15) * 2.5; const m = new THREE.Mesh(new THREE.PlaneGeometry(R(2.5, 4), R(2, 3)), scMat); m.rotation.x = -Math.PI / 2; m.rotation.z = rng() * 6; m.position.set(x, 0.06, z); this.scorchGroup.add(m); this.scorch.push({ x, z }); }
    this.scorchGroup.visible = false;
    this.sets.pineW.mesh.visible = false; this.sets.bigW.mesh.visible = false;
  }
  // ---------- state ----------
  setWinter(on) {
    this.winter = on; this.paintTiles(on);
    this.sets.pine.mesh.visible = !on; this.sets.big.mesh.visible = !on; this.sets.pineW.mesh.visible = on; this.sets.bigW.mesh.visible = on; this.scorchGroup.visible = on;
    if (this.sets.oak) { const img = on ? PX.propOak(true) : Assets.src('sprite_tree_oak', PX.propOak(false)); this.sets.oak.mesh.material = this.sets.oak.mesh.material.clone(); const t = new THREE.Texture(img); t.needsUpdate = true; t.magFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace; this.sets.oak.mesh.material.map = t; }
    this.sets.rock.mesh.material.color.setHex(on ? 0xc9d6e2 : 0xffffff);
  }
  setNight(on) { this.night = on; for (const l of this.plazaLights) l.intensity = on ? 40 : 0; this.forgeLight.intensity = on ? 16 : 8; }
  setLightStolen(on) { this.lightMesh.visible = this.lightGlow.visible = this.lightBeam.visible = !on; this.lightPoint.intensity = on ? 0 : 120; }
  buildSewer() {
    const S = SEWER, w = S.x1 - S.x0, d = S.z1 - S.z0, cx = (S.x0 + S.x1) / 2, cz = (S.z0 + S.z1) / 2;
    const wallMat = this.mk(this.tex.sewer, 4, 1); wallMat.color.setHex(0x6a7a70); const H = 3;
    const wall = (x, z, ww, dd) => { const m = this.box(ww, H, dd, wallMat, x, H / 2, z); this.addBox(x, z, ww, dd); return m; };
    // outer ring
    wall(cx, S.z0, w + 2, 2); wall(cx, S.z1, w + 2, 2); wall(S.x0, cz, 2, d); wall(S.x1, cz, 2, d);
    // inner walls: a few long corridors and rooms
    wall(S.x0 + 45, S.z0 + 40, 70, 2); wall(S.x1 - 45, S.z0 + 70, 70, 2); wall(S.x0 + 45, S.z0 + 100, 70, 2);
    wall(S.x0 + 30, S.z0 + 20, 2, 30); wall(S.x1 - 30, S.z0 + 85, 2, 40); wall(S.x0 + 75, S.z1 - 20, 2, 30);
    // sewage channel along the south edge with a narrow bridge
    this.colliders.push({ type: 'box', minX: S.x0 + 2, maxX: cx - 3, minZ: S.z1 - 12, maxZ: S.z1 - 4 }, { type: 'box', minX: cx + 3, maxX: S.x1 - 2, minZ: S.z1 - 12, maxZ: S.z1 - 4 });
    this.sewerLights = [[S.x0 + 20, S.z0 + 20], [S.x1 - 20, S.z0 + 55], [cx, S.z0 + 85], [S.x0 + 20, S.z1 - 25], [S.x1 - 25, S.z1 - 25]].map(([x, z]) => { const l = new THREE.PointLight(0x7fd08a, 14, 30, 1.6); l.position.set(x, 2.5, z); this.scene.add(l); return l; });
  }
  // ---------- terrain tiles ----------
  buildTiles() {
    const tm = this.tiles = new TileMap(this.scene, WORLD), S = SEWER;
    tm.fillRect(-WALL, -WALL, WALL, WALL, T.cobble);
    for (const r of this.roads) tm.fillRect(r.x - r.w / 2, r.z - r.d / 2, r.x + r.w / 2, r.z + r.d / 2, T.dirt);
    tm.fillRect(-163, -WORLD, -137, WORLD, T.water);
    for (const p of this.plazas) tm.fillCircle(p.x, p.z, p.r, T.plaza);
    tm.fillRect(52, 50, 88, 90, T.grass); tm.fillRect(52, 72, 88, 76, T.dirt); tm.fillRect(68, 50, 72, 90, T.dirt);   // Jardins: lawn with paths
    for (const [px, pz] of [[-80, 56], [-62, 56], [-80, 78], [-62, 78]]) tm.fillRect(px - 7, pz - 5, px + 7, pz + 5, T.soil);   // Hortas
    tm.fillRect(52, -77, 78, -57, T.dirt);   // Campo de Treino
    tm.fillRect(-86, -69, -50, -56, T.plaza);   // castle yard
    tm.fillRect(-23, 52, -13, 60, T.planks);   // Thomas's house floor
    tm.fillRect(S.x0, S.z0, S.x1, S.z1, T.sewer); tm.fillRect(S.x0 + 2, S.z1 - 12, S.x1 - 2, S.z1 - 4, T.sewage);
    tm.rasterize(this.colliders); this.paintTiles(false); tm.build();
  }
  paintTiles(winter) {
    const img = t => this.tex[t].image; const shade = (src, color, alpha) => { const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(src, 0, 0, 128, 128); x.fillStyle = color; x.globalAlpha = alpha; x.fillRect(0, 0, 128, 128); return c; };
    const soil = (() => { const c = shade(img('dirt'), '#3a2a18', 0.35); const x = c.getContext('2d'); x.globalAlpha = 0.5; x.fillStyle = '#2a1a0c'; for (let y = 6; y < 128; y += 16) x.fillRect(0, y, 128, 3); return c; })();
    this.tiles.paintAtlas({ [T.grass]: winter ? img('snow') : img('grass'), [T.cobble]: winter ? shade(img('cobble'), '#dde6ee', 0.35) : img('cobble'), [T.dirt]: winter ? shade(img('dirt'), '#e6ecf2', 0.45) : img('dirt'), [T.water]: winter ? img('ice') : img('water'), [T.plaza]: winter ? shade(img('cobble'), '#e8eef4', 0.5) : shade(img('cobble'), '#fff2d0', 0.22), [T.sewer]: img('sewer'), [T.sewage]: img('sewage'), [T.soil]: winter ? shade(soil, '#e6ecf2', 0.5) : soil, [T.planks]: img('planks') });
  }
  inSewer(x, z) { return x < SEWER.x1 && z > SEWER.z0; }
  // Top-down view: buildings standing between the camera (south) and Thomas, or that he walks into, turn see-through so they never hide him.
  registerFade(group, x, z, w, d, h) { group.traverse(m => { if (m.isMesh) { m.material = m.material.clone(); m.material.transparent = true; } }); (this.fadeables = this.fadeables || []).push({ group, x, z, w, d, h, op: 1 }); }
  fadeNear(px, pz, dt) {
    for (const f of this.fadeables || []) {
      const inside = Math.abs(px - f.x) < f.w / 2 + 1.5 && Math.abs(pz - f.z) < f.d / 2 + 1.5;
      const inFront = f.z - f.d / 2 < pz + f.h * 0.6 + 2 && f.z + f.d / 2 > pz - 1 && Math.abs(px - f.x) < f.w / 2 + 2;   // south of Thomas, in the camera's line of sight
      const target = inside || inFront ? 0.18 : 1; if (Math.abs(f.op - target) < 0.01 && f.op === target) continue;
      f.op += (target - f.op) * Math.min(1, dt * 8); if (Math.abs(f.op - target) < 0.01) f.op = target;
      f.group.traverse(m => { if (m.isMesh) { m.material.opacity = f.op; m.castShadow = f.op > 0.5; } });
    }
    const b = this.homeBox; this.homeRoof.visible = !(Math.abs(px - b.x) < b.w / 2 + 2.5 && Math.abs(pz - b.z) < b.d / 2 + 2.5);
  }
  regionAt(x, z) {
    if (Math.abs(x) < WALL && Math.abs(z) < WALL) { if (Math.hypot(x, z + 44) < 14) return 'Praça da Luz'; if (Math.hypot(x, z) < 17) return 'Praça da Fonte'; if (x < -48 && z < -54) return 'Castelo Real'; if (x > 50 && z > 48) return 'Jardins'; if (x > 50 && z < -54) return 'Campo de Treino'; if (x < -50 && z > 48) return 'Hortas'; if (x < -12 && Math.abs(z) < 10) return 'Mercado'; if (z > 40) return 'Bairro das Casas'; if (z < -40) return 'Bairro Alto'; return 'Fortaleza do Relâmpago Amarelo'; }
    if (x < SEWER.x1 && z > SEWER.z0) return 'Esgoto'; if (x > WALL + 175) return 'Floresta Congelada'; if (x > WALL) return 'Campos do Vale'; if (x < -120) return 'Margem do Rio'; return 'Arredores da Fortaleza';
  }
  // ---------- physics ----------
  blocked(x, z, r) { for (const c of this.colliders) { if (c.type === 'box') { if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r) return true; } else { const dx = x - c.x, dz = z - c.z; if (dx * dx + dz * dz < (c.r + r) * (c.r + r)) return true; } } return false; }
  resolveMove(pos, dx, dz, r = 0.45) { if (!this.blocked(pos.x + dx, pos.z, r)) pos.x += dx; if (!this.blocked(pos.x, pos.z + dz, r)) pos.z += dz; }
  update(dt, t) {
    const pulse = 1 + Math.sin(t * 3) * 0.12; this.lightGlow.scale.set(12 * pulse, 12 * pulse, 1); this.lightMesh.rotation.y += dt * 1.5; this.lightMesh.rotation.x += dt; if (this.lightMesh.visible) this.lightPoint.intensity = 120 * pulse;
    this.forgeLight.intensity = (this.night ? 14 : 7) + Math.sin(t * 7) * 3;
    if (!this.winter) this.tiles.atlasTex.offset.y = 0;
  }
}
