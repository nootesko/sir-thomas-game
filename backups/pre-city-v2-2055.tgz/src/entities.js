import * as THREE from 'three';
import * as S from './sprites.js';
import { Assets } from './assets.js';
import { makeBillboard, setBillboardImage, faceView } from './billboard.js';
const _v = new THREE.Vector3();
function label(text, color) { const c = document.createElement('canvas'); c.width = 256; c.height = 48; const x = c.getContext('2d'); x.font = 'bold 26px Trebuchet MS, sans-serif'; x.textAlign = 'center'; x.lineWidth = 6; x.strokeStyle = '#000'; x.strokeText(text, 128, 34); x.fillStyle = color; x.fillText(text, 128, 34); const t = new THREE.CanvasTexture(c); t.magFilter = THREE.NearestFilter; const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false })); s.scale.set(3.2, 0.6, 1); return s; }

export class NPC {
  constructor(game, { id, name, x, z, sprite, asset, color = '#fff', dialog, h = 1.9, kind = 'npc', path = null }) {
    this.game = game; this.id = id; this.name = name; this.kind = kind; this.alive = true; this.hittable = false; this.radius = 0.5; this.dialog = dialog; this.blocking = true;
    this.pos = new THREE.Vector3(x, 0, z); const src = (asset && Assets.has(asset)) ? Assets.images[asset] : sprite; const ratio = src.width / src.height;
    this.mesh = makeBillboard(src, h * ratio, h); this.mesh.position.copy(this.pos); game.scene.add(this.mesh);
    if (name) { this.label = label(name, color); this.label.position.set(0, 1 + 0.3 / h, 0); this.mesh.add(this.label); this.label.scale.set(3.2 / (h * ratio), 0.6 / h, 1); }
    this.t = Math.random() * 6; this.path = path; this.pi = 0; this.wait = 0; this.speed = 1.6; game.city.addCircle(x, z, 0.4); this.colIndex = game.city.colliders.length - 1;
  }
  moveTo(x, z) { this.pos.set(x, 0, z); this.mesh.position.copy(this.pos); const c = this.game.city.colliders[this.colIndex]; if (c) { c.x = x; c.z = z; } }
  update(dt) {
    this.t += dt;
    if (this.path && !this.game.player.frozen) {
      if (this.wait > 0) this.wait -= dt; else { const tgt = this.path[this.pi]; _v.set(tgt[0] - this.pos.x, 0, tgt[1] - this.pos.z); const d = _v.length(); if (d < 0.4) { this.pi = (this.pi + 1) % this.path.length; this.wait = 1 + Math.random() * 3; } else { _v.normalize(); this.pos.x += _v.x * this.speed * dt; this.pos.z += _v.z * this.speed * dt; const c = this.game.city.colliders[this.colIndex]; if (c) { c.x = this.pos.x; c.z = this.pos.z; } } }
    }
    this.mesh.position.set(this.pos.x, Math.abs(Math.sin(this.t * 2)) * 0.02 + (this.path && this.wait <= 0 ? Math.abs(Math.sin(this.t * 10)) * 0.08 : 0), this.pos.z);
    faceView(this.mesh);
  }
}

export class Boss {   // Mordrak as a giant vulture; scripted Chapter I fight
  constructor(game, center) {
    this.game = game; this.kind = 'boss'; this.alive = true; this.hittable = true; this.radius = 2.5; this.blocking = false;
    this.center = center.clone(); this.pos = center.clone().add(new THREE.Vector3(0, 50, 40)); this.phase = 'arrive'; this.t = 0; this.hits = 0; this.fightT = 0; this.flash = 0; this.swoop = null; this.cool = 2; this.smoke = []; this.carrying = false;
    const src0 = Assets.has('sprite_mordrak_vulture') ? Assets.images.sprite_mordrak_vulture : S.VULTURE[0]; const ratio = src0.width / src0.height; this.w = 9; this.h = 9 / ratio;
    this.mesh = makeBillboard(src0, this.w, this.h); this.game.scene.add(this.mesh); this.frames = Assets.has('sprite_mordrak_vulture') ? [src0] : S.VULTURE;
    this.smokeMat = new THREE.MeshBasicMaterial({ color: 0x1a1020, transparent: true, opacity: 0.8 });
  }
  takeDamage() { if (this.phase !== 'fight' || !this.near) return; this.hits++; this.flash = 0.2; this.game.audio.vulture(); this.game.hud.toast(`Acertou Mordrak! (${this.hits}/4)`); }
  grab() { const c = this.game.city; c.lightMesh.visible = false; c.lightBeam.visible = false; c.lightGlow.visible = false; this.carrying = true; this.gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.8, 0), new THREE.MeshBasicMaterial({ color: 0xffe066 })); this.game.scene.add(this.gem); this.gemLight = new THREE.PointLight(0xffd23a, 60, 40); this.game.scene.add(this.gemLight); c.lightPoint.intensity = 0; }
  puff(at, size) { const m = new THREE.Mesh(new THREE.DodecahedronGeometry(size, 0), this.smokeMat.clone()); m.position.copy(at); m.userData = { t: 0, vel: new THREE.Vector3(S.rand(-1, 1), S.rand(0.5, 1.5), S.rand(-1, 1)) }; this.game.scene.add(m); this.smoke.push(m); }
  update(dt) {
    const p = this.game.player; this.t += dt; const c = this.center; this.flash -= dt; this.near = false;
    if (this.frames.length > 1) setBillboardImage(this.mesh, this.frames[Math.floor(this.t * (this.phase === 'fight' ? 8 : 5)) % 2]);
    if (this.phase === 'arrive') { _v.set(c.x, c.y + 1.5, c.z); this.pos.lerp(_v, 1 - Math.pow(0.001, dt)); if (this.pos.distanceTo(_v) < 0.8) { this.grab(); this.phase = 'hover'; this.t = 0; this.game.audio.vulture(); } }
    else if (this.phase === 'hover') { const a = this.t * 0.6; _v.set(c.x + Math.cos(a) * 12, c.y - 8 + Math.sin(this.t) * 1.5, c.z + Math.sin(a) * 12); this.pos.lerp(_v, 1 - Math.pow(0.01, dt)); }
    else if (this.phase === 'fight') {
      this.fightT += dt; this.cool -= dt; const ap = this.game.city.altar;
      if (!this.swoop) { const a = this.t * 0.9; _v.set(ap.x + Math.cos(a) * 10, 9 + Math.sin(this.t * 1.3), ap.z + Math.sin(a) * 10); this.pos.lerp(_v, 1 - Math.pow(0.02, dt)); if (this.cool <= 0) { this.swoop = { t: 0, from: this.pos.clone(), to: p.pos.clone().add(new THREE.Vector3(0, 1.6, 0)), hit: false }; this.game.audio.vulture(); } }
      else { const s = this.swoop; s.t += dt / 1.1; const k = s.t;
        if (k < 1) { this.pos.lerpVectors(s.from, s.to, k); this.pos.y += Math.sin(k * Math.PI) * -2; if (k > 0.55) this.near = this.pos.distanceTo(p.pos) < 6; if (k > 0.8 && !s.hit) { s.hit = true; if (this.pos.distanceTo(p.pos) < 4.5) p.takeDamage(14, this.pos); } }
        else if (k < 1.7) { this.near = this.pos.distanceTo(p.pos) < 5; this.pos.y += 7 * dt; this.pos.addScaledVector(_v.copy(s.to).sub(s.from).setY(0).normalize(), 5 * dt); }
        else { this.swoop = null; this.cool = 2.0; } }
      if (this.hits >= 4 || this.fightT > 60) { this.phase = 'charge'; this.t = 0; this.swoop = null; this.game.onBossCharge(); }
    }
    else if (this.phase === 'charge') { _v.copy(p.pos).add(p.forward.multiplyScalar(8)).setY(p.pos.y + 4); this.pos.lerp(_v, 1 - Math.pow(0.01, dt)); if (Math.random() < dt * 25) this.puff(this.pos.clone().add(new THREE.Vector3(S.rand(-2, 2), S.rand(-1, 1), S.rand(-2, 2))), S.rand(0.3, 0.9)); if (this.t > 2.8) { this.phase = 'blast'; this.t = 0; for (let i = 0; i < 40; i++) this.puff(this.pos.clone().add(new THREE.Vector3(S.rand(-2, 2), S.rand(-1, 1), S.rand(-2, 2))), S.rand(0.5, 1.5)); this.game.onBossBlast(); } }
    else if (this.phase === 'blast') { this.smoke.forEach(m => m.userData.vel.lerp(_v.copy(p.pos).setY(p.pos.y + 1.4).sub(m.position).normalize().multiplyScalar(14), 0.2)); if (this.t > 0.9) { this.phase = 'done'; this.t = 0; } }
    else if (this.phase === 'done') { this.pos.y += 14 * dt; this.pos.x += 10 * dt; }
    this.mesh.position.copy(this.pos); this.mesh.position.y -= this.h / 2; faceView(this.mesh); this.mesh.material.color.setHex(this.flash > 0 ? 0xff6060 : this.game.sky.tint);
    if (this.gem) { this.gem.position.copy(this.pos).add(new THREE.Vector3(0, -this.h / 2 - 0.3, 0)); this.gem.rotation.y += dt * 2; this.gemLight.position.copy(this.gem.position); }
    for (let i = this.smoke.length - 1; i >= 0; i--) { const m = this.smoke[i]; m.userData.t += dt; m.position.addScaledVector(m.userData.vel, dt); m.scale.multiplyScalar(1 + dt * 0.6); m.material.opacity = Math.max(0, 0.8 - m.userData.t * 0.35); if (m.material.opacity <= 0) { this.game.scene.remove(m); this.smoke.splice(i, 1); } }
  }
  remove() { this.game.scene.remove(this.mesh); if (this.gem) { this.game.scene.remove(this.gem); this.game.scene.remove(this.gemLight); } this.smoke.forEach(m => this.game.scene.remove(m)); }
}

export class Prop {   // chests, campfires, lore objects, shield prop
  constructor(game, { kind, x, z, w, h, src, item, lit, title, text, yOff = 0, collide = true, flat = false }) {
    this.game = game; this.kind = kind; this.pos = new THREE.Vector3(x, 0, z); this.item = item; this.opened = false; this.lit = !!lit; this.title = title; this.text = text; this.alive = true; this.hittable = false; this.radius = 0.5; this.t = Math.random() * 6; this.blocking = collide;
    this.srcs = Array.isArray(src) ? src : [src]; this.w = w; this.h = h; this.mesh = makeBillboard(this.srcs[0], w, h); this.mesh.position.set(x, yOff, z); this.flat = flat; if (flat) { this.mesh.rotation.x = -Math.PI / 2; this.mesh.position.z += h / 2; } game.scene.add(this.mesh);
    if (collide) game.city.addCircle(x, z, 0.6);
    if (kind === 'fire') { this.light = new THREE.PointLight(0xff8c2a, 0, 18, 1.5); this.light.position.set(x, 1.4, z); game.scene.add(this.light); }
  }
  update(dt) {
    this.t += dt; if (!this.flat) faceView(this.mesh);
    if (this.kind === 'fire') { const img = this.lit ? (this.srcs.length > 2 ? this.srcs[1 + Math.floor(this.t * 8) % 2] : this.srcs[1] || this.srcs[0]) : this.srcs[0]; setBillboardImage(this.mesh, img); this.light.intensity = this.lit ? 22 + Math.sin(this.t * 9) * 4 : 0; }
    if (this.kind === 'chest') setBillboardImage(this.mesh, this.srcs[this.opened ? 1 : 0]);
  }
}
