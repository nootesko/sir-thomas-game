// Monsters: one data-driven class for every creature. Killing one gives XP, drops items and coins, and it respawns later.
import * as THREE from 'three';
import * as S from './sprites.js';
import { Assets } from './assets.js';
import { ITEMS } from './items.js';
import { iconFor } from './icons.js';
import { makeBillboard, setBillboardImage, faceView } from './billboard.js';
const _v = new THREE.Vector3();
const R = (a, b) => a + Math.random() * (b - a);
export const MONSTERS = {
  coelho:    { name: 'Coelho', hp: 12, dmg: 0, speed: 5.5, aggro: 0, flee: 6, xp: 4, h: 0.8, asset: 'sprite_coelho', fb: 'RABBIT', drops: [['pe_coelho', 0.35], ['carne', 0.5]], gold: [0, 2], respawn: 25 },
  lobo:      { name: 'Lobo', hp: 40, dmg: 10, speed: 6, aggro: 16, xp: 18, h: 1.4, asset: 'sprite_lobo', fb: 'WOLF_GRAY', drops: [['pele_lobo', 0.5], ['carne', 0.4]], gold: [2, 6], respawn: 45 },
  lobo_gelo: { name: 'Lobo de Gelo', hp: 42, dmg: 12, speed: 6.2, aggro: 22, xp: 24, h: 1.5, asset: 'sprite_wolf_ice', fb: 'WOLF', drops: [['pele_lobo', 0.6]], gold: [3, 8], respawn: 60, howl: true },
  abelha:    { name: 'Abelha Gigante', hp: 18, dmg: 6, speed: 7.5, aggro: 12, xp: 10, h: 0.9, fly: 0.9, asset: 'sprite_abelha', fb: 'BEE', drops: [['ferrao_abelha', 0.5], ['mel', 0.35]], gold: [1, 3], respawn: 30 },
  serpente:  { name: 'Serpente', hp: 30, dmg: 14, speed: 3.5, aggro: 8, xp: 16, h: 0.9, asset: 'sprite_serpente', fb: 'SNAKE', drops: [['escama_serpente', 0.5]], gold: [2, 5], respawn: 40 },
  rato:      { name: 'Rato do Esgoto', hp: 14, dmg: 5, speed: 5.5, aggro: 10, xp: 6, h: 0.7, asset: 'sprite_rato', fb: 'RAT', drops: [['rabo_rato', 0.6], ['queijo', 0.25]], gold: [0, 3], respawn: 20 },
  barata:    { name: 'Barata Gigante', hp: 10, dmg: 3, speed: 6.5, aggro: 9, xp: 4, h: 0.6, asset: 'sprite_barata', fb: 'ROACH', drops: [['asa_barata', 0.7]], gold: [0, 1], respawn: 15 },
};

export class Monster {
  constructor(game, id, x, z) {
    const c = MONSTERS[id]; this.game = game; this.id = id; this.cfg = c; this.name = c.name; this.kind = 'monster'; this.hittable = true; this.blocking = false; this.radius = 0.6;
    this.pos = new THREE.Vector3(x, 0, z); this.home = this.pos.clone(); this.hp = c.hp; this.alive = true; this.state = 'idle'; this.cool = 0; this.t = Math.random() * 6; this.flash = 0; this.slow = 0; this.burn = 0; this.dieT = 0; this.respawnT = 0; this.lunge = null; this.wander = null; this.wanderWait = R(1, 4);
    const src = Assets.has(c.asset) ? Assets.images[c.asset] : S[c.fb]; const ratio = src.width / src.height; this.h = c.h; this.mesh = makeBillboard(src, c.h * ratio, c.h); this.mesh.position.copy(this.pos); game.scene.add(this.mesh);
    this.mesh.material = this.mesh.material.clone();   // own material so the hit flash does not tint every sprite that shares the image
  }
  get hostile() { return this.cfg.aggro > 0; }
  takeDamage(d, from, sword) {
    if (!this.alive) return; this.hp -= d; this.flash = 0.15; if (sword === 'glacial') this.slow = 2.5; if (sword === 'fogo') this.burn = 3;
    _v.copy(this.pos).sub(from).setY(0).normalize(); this.game.city.resolveMove(this.pos, _v.x * 0.8, _v.z * 0.8, 0.5); this.cool = Math.max(this.cool, 0.4);
    this.state = this.hostile ? 'chase' : 'flee'; this.fleeT = 3;
    if (this.hp <= 0) this.die();
  }
  die() {
    const g = this.game, p = g.player, c = this.cfg; this.alive = false; this.dieT = 0; this.respawnT = c.respawn; p.stats.kills = (p.stats.kills || 0) + 1; if (this.id.startsWith('lobo')) p.stats.wolves++;
    if (c.howl || this.id === 'lobo') g.audio.wolf(); else g.audio.squeak(); p.gainXp(c.xp); g.hud.toast(`${c.name} derrotado · +${c.xp} XP`, 1800);
    const items = []; for (const [id, chance] of c.drops) if (Math.random() < chance) items.push(id);
    const gold = Math.round(R(c.gold[0], c.gold[1])); g.spawnLoot(this.pos, items, gold);
  }
  revive() { this.alive = true; this.hp = this.cfg.hp; this.pos.copy(this.home); this.state = 'idle'; this.mesh.visible = true; this.mesh.rotation.z = 0; this.burn = 0; this.slow = 0; }
  update(dt) {
    const p = this.game.player, c = this.cfg, m = this.mesh; this.t += dt;
    if (!this.alive) { this.dieT += dt; if (this.dieT < 4) { m.rotation.z = Math.min(Math.PI / 2, this.dieT * 4); m.position.y = -Math.max(0, this.dieT - 1.5) * 0.6; } else { m.visible = false; this.respawnT -= dt; if (this.respawnT <= 0 && this.pos.distanceTo(p.pos) > 30) this.revive(); } faceView(m); m.rotation.z = m.visible ? m.rotation.z : 0; return; }
    this.flash -= dt; m.material.color.setHex(this.flash > 0 ? 0xff6060 : this.burn > 0 ? 0xffa050 : this.game.sky.tint);
    if (this.burn > 0) { this.burn -= dt; this.hp -= 4 * dt; if (this.hp <= 0) { this.die(); return; } }
    this.slow = Math.max(0, this.slow - dt); const sp = this.slow > 0 ? c.speed * 0.4 : c.speed; this.cool -= dt;
    const d = this.pos.distanceTo(p.pos); const canSee = !p.dead && !p.frozen;
    if (this.state === 'flee') { this.fleeT -= dt; _v.copy(this.pos).sub(p.pos).setY(0).normalize(); this.game.city.resolveMove(this.pos, _v.x * sp * 1.3 * dt, _v.z * sp * 1.3 * dt, 0.4); if (this.fleeT <= 0 || d > 25) this.state = 'idle'; }
    else if (this.state === 'idle') {
      if (this.hostile && canSee && d < c.aggro) { this.state = 'chase'; if (c.howl) this.game.audio.wolf(); }
      else if (!this.hostile && canSee && c.flee && d < c.flee) { this.state = 'flee'; this.fleeT = 2.5; }
      else this.doWander(dt, sp);
    }
    else if (this.state === 'chase') {
      if (!canSee || d > c.aggro * 2.5 || this.pos.distanceTo(this.home) > 60) this.state = 'return';
      else if (d < 2.2 && this.cool <= 0) { this.state = 'lunge'; this.lunge = { t: 0, dir: _v.copy(p.pos).sub(this.pos).setY(0).normalize().clone(), hit: false }; }
      else if (d >= 1.8) { _v.copy(p.pos).sub(this.pos).setY(0).normalize(); const strafe = Math.sin(this.t * 1.5) * 0.4; this.game.city.resolveMove(this.pos, (_v.x - _v.z * strafe) * sp * dt, (_v.z + _v.x * strafe) * sp * dt, 0.5); }
    }
    else if (this.state === 'lunge') {
      const L = this.lunge; L.t += dt; const k = L.t / 0.5; this.game.city.resolveMove(this.pos, L.dir.x * 9 * dt, L.dir.z * 9 * dt, 0.5);
      if (k > 0.35 && !L.hit && this.pos.distanceTo(p.pos) < 2.3) { L.hit = true; p.takeDamage(c.dmg, this.pos); }
      if (k >= 1) { this.state = 'chase'; this.cool = 1.4; }
    }
    else if (this.state === 'return') { _v.copy(this.home).sub(this.pos).setY(0); if (_v.length() < 1) { this.state = 'idle'; this.hp = Math.min(c.hp, this.hp + c.hp * 0.5); } else { _v.normalize(); this.game.city.resolveMove(this.pos, _v.x * sp * dt, _v.z * sp * dt, 0.4); } }
    const hop = this.state === 'lunge' ? Math.sin(this.lunge.t / 0.5 * Math.PI) * 0.6 : 0; const fly = c.fly ? c.fly + Math.sin(this.t * 6) * 0.15 : 0;
    m.position.set(this.pos.x, hop + fly, this.pos.z); faceView(m); m.rotation.z = 0;
    m.scale.x = Math.abs(m.scale.x) * (p.pos.x < this.pos.x ? -1 : 1);
  }
  doWander(dt, sp) {
    if (this.wander) { _v.copy(this.wander).sub(this.pos).setY(0); if (_v.length() < 0.5) { this.wander = null; this.wanderWait = R(1, 5); } else { _v.normalize(); this.game.city.resolveMove(this.pos, _v.x * sp * 0.4 * dt, _v.z * sp * 0.4 * dt, 0.4); } }
    else { this.wanderWait -= dt; if (this.wanderWait <= 0) this.wander = new THREE.Vector3(this.home.x + R(-6, 6), 0, this.home.z + R(-6, 6)); }
  }
}

// An item or a pile of coins lying on the ground; picked up by walking over it.
export class Loot {
  constructor(game, x, z, item, qty = 1, gold = 0) {
    this.game = game; this.kind = 'loot'; this.item = item; this.qty = qty; this.gold = gold; this.alive = true; this.hittable = false; this.blocking = false; this.radius = 0.3; this.t = Math.random() * 6; this.life = 120;
    this.pos = new THREE.Vector3(x, 0, z); this.mesh = makeBillboard(gold ? iconFor('moedas') : iconFor(ITEMS[item].icon), 0.6, 0.6); this.mesh.material = this.mesh.material.clone(); this.mesh.material.depthTest = false; this.mesh.renderOrder = 15; game.scene.add(this.mesh);
  }
  update(dt) {
    this.t += dt; this.life -= dt; const p = this.game.player; this.mesh.position.set(this.pos.x, 0.15 + Math.abs(Math.sin(this.t * 3)) * 0.15, this.pos.z); faceView(this.mesh);
    if (this.life <= 0) this.remove(); else if (!p.dead && this.pos.distanceTo(p.pos) < 1.6) { if (this.gold) this.game.addGold(this.gold); else this.game.addItem(this.item, this.qty); this.game.audio.pickup(); this.remove(); }
  }
  remove() { this.game.scene.remove(this.mesh); this.removed = true; }
}
