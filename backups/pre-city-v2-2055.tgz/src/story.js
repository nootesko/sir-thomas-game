import * as THREE from 'three';
import { ITEMS, SHOPS } from './items.js';
const wait = ms => new Promise(r => setTimeout(r, ms));
export class Story {
  constructor(game) { this.game = game; this.flags = {}; this.chapter = 'prologue'; this.target = null; }
  waitUntil(fn) { return new Promise(res => { const tick = () => fn() ? res() : requestAnimationFrame(tick); tick(); }); }
  objective(text, target) { this.game.hud.objective(text); this.target = target ? { x: target.x, z: target.z } : null; }
  async simpleDialog(name, lines) { await this.game.hud.dialog(lines.map(l => [name, l])); }
  npcDialog(id) {
    const pro = this.chapter === 'prologue';
    const texts = {
      ferreiro: pro ? ['Sir Thomas! Sua espada está afiada? Passe aqui sempre que precisar.', 'Hoje forjei dobradiças para o portão. Trabalho pequeno... mas é o que mantém a fortaleza de pé.'] : ['O escudo... partiu-se em três. E aquele fragmento amarelo não sai de jeito nenhum.', 'A princesa mandou não tirar. Vou forjar um escudo novo em volta dele. Vai levar tempo, Thomas.'],
      cozinheira: pro ? ['Thomas, menino! Tem sopa de abóbora no fogo. O vale deu uma colheita e tanto este ano.', 'Com a Luz lá em cima, nada falta por aqui. Que ela brilhe para sempre.'] : ['As hortas congelaram da noite para o dia. Estou racionando o que sobrou.', 'Leve uma sopa quente antes de sair. Lá fora o frio morde.'],
      guarda: pro ? ['Tudo calmo no portão, Sir Thomas. Só uns corvos rondando a torre hoje de manhã. Corvos grandes.', 'Deve ser nada.'] : ['Vi aquela coisa voar para leste, por cima da floresta. Deixou um rastro preto na estrada.', 'Se for atrás... volte inteiro.'],
      pipo: pro ? ['Sir Thomas! Quando eu crescer vou ter uma espada igual à sua!', 'Olha a Luz lá em cima! Dá pra ver ela de qualquer lugar da cidade!'] : ['Thomas... a Luz apagou. Minha mãe disse que o inverno voltou.', 'Você vai buscar ela de volta, né?'],
      mercador: pro ? ['Sir Thomas! Poções, pão, capas... e compro qualquer coisa que você trouxer da caça: peles, ferrões, escamas.', 'Os campos a leste estão cheios de coelhos e abelhas. E dizem que ratos tomaram o esgoto, perto do cruzamento das ruas.'] : ['Com esse frio as poções vendem como pão quente. Trouxe peles de lobo?'],
    };
    const names = { ferreiro: 'Ferreiro Bruno', cozinheira: 'Dona Rosa', guarda: 'Guarda Olavo', pipo: 'Pipo', mercador: 'Mercador Gaspar' };
    if (id === 'maite') return this.maiteDialog(); if (texts[id]) return this.simpleDialog(names[id], texts[id]).then(() => { if (SHOPS[id]) this.game.hud.shop(id); });
    const vil = pro ? [['Que dia bonito! A praça está cheia hoje.'], ['Dizem que a sopa da Dona Rosa está melhor do que nunca.'], ['O ferreiro Bruno faz as melhores dobradiças do vale.'], ['Já viu a Luz brilhar assim? Nunca vi tão forte.']] : [['Está frio demais. Nunca vi neve dentro das muralhas.'], ['O rio parou de correr. Isso não é normal.'], ['A princesa está cuidando de todo mundo. Que menina corajosa.'], ['Dizem que uma sombra voou para a floresta.']];
    return this.simpleDialog('Morador', vil[Math.floor(Math.random() * vil.length)]);
  }
  async maiteDialog() {
    const h = this.game.hud;
    if (this.chapter === 'prologue') { await h.dialog([['Princesa Maite', 'Thomas! Dormiu até agora? O sol já está alto.'], ['Sir Thomas', 'Eu estava sonhando com um urubu enorme. Ridículo, eu sei.'], ['Princesa Maite', 'Olha a torre. A Luz nunca brilhou tanto. A cidade inteira está viva por causa dela.'], ['Princesa Maite', 'Dá uma volta pela cidade, fala com o pessoal. E descansa cedo hoje. Amanhã tem muito o que fazer.']]); this.flags.talkedMaite = true; }
    else if (this.chapter === 'winter' && !this.flags.talkedMaite2) { await h.dialog([['Princesa Maite', 'Thomas... você acordou. Achei que o escudo tinha...'], ['Sir Thomas', 'O escudo quebrou. A Luz... ele levou a Luz, Maite.'], ['Princesa Maite', 'Eu sei. O rio parou. As hortas congelaram em uma noite. As pessoas estão com medo.'], ['Princesa Maite', 'Aquilo não era um urubu comum. Na Floresta Congelada vive alguém que sabe de coisas antigas. Chamam de Sábia Coruja.'], ['Princesa Maite', 'O urubu deixou marcas de fumaça negra na estrada do leste. Siga as marcas até a floresta. Eu cuido da cidade.'], ['Sir Thomas', 'E o escudo?'], ['Princesa Maite', 'Deixa o escudo comigo.']]); this.flags.talkedMaite2 = true; }
    else if (this.chapter === 'winter') await h.dialog([['Princesa Maite', 'Saia pelo portão leste e siga as marcas negras. Acenda fogueiras no caminho: o frio aqui fora é de verdade.']]);
    else await h.dialog([['Princesa Maite', 'Thomas, corre! A torre!']]);
  }
  async run(save) {
    const g = this.game, h = g.hud, p = g.player, c = g.city;
    if (save) return this.winter(save);
    p.teleport(-18, 50, Math.PI); p.leftItem = 'none';
    await h.fade(0, 2.5); h.chapter('PRÓLOGO', 'O Vale Vivo'); await wait(2500);
    this.objective('Explore a cidade e fale com a Princesa Maite na praça', g.npcs.maite.pos);
    await this.waitUntil(() => this.flags.talkedMaite);
    g.setPreset('dusk'); this.objective('Converse com os moradores. Quando quiser, descanse na sua cama', c.bedPos); this.flags.canSleep = true;
    await this.waitUntil(() => this.flags.slept);
    // ---- Chapter I ----
    await h.fade(1, 1.5); this.chapter = 'night'; g.setPreset('night'); p.teleport(-18, 50, Math.PI); p.leftItem = 'shield'; p.frozen = true; g.villagersVisible(false);
    await wait(1200); h.fade(0, 2); await wait(2500);
    g.audio.crash(); p.shake = 1.8; h.toast('CRAASH!', 1500); await wait(1200);
    h.chapter('CAPÍTULO I', 'A Noite Sem Luz'); p.frozen = false;
    this.objective('Algo aconteceu na Torre da Luz! Corra até a Praça da Luz', c.altar);
    g.spawnBoss(); g.guardsRun(); h.toast('Mordrak está na torre!', 2000);
    await this.waitUntil(() => p.pos.distanceTo(c.altar) < 9);
    g.boss.phase = 'fight'; g.boss.t = 0;
    this.objective('Impeça o urubu! Acerte-o quando ele mergulhar', null);
    h.toast('CLIQUE para atacar · BOTÃO DIREITO para defender · ESPAÇO para esquivar', 6000);
    await this.waitUntil(() => g.boss && g.boss.phase === 'done');
    await wait(400); g.audio.boom(); p.shake = 2.5; g.flash = 1.6; await wait(500); await h.fade(1, 0.6); p.frozen = true; p.leftItem = 'none'; p.hp = Math.max(p.hp, 30);
    await wait(2500); await this.winter(null);
  }
  async winter(save) {
    const g = this.game, h = g.hud, p = g.player, c = g.city;
    this.chapter = 'winter'; this.flags.shieldBroken = true; if (g.boss) { g.boss.remove(); g.entities = g.entities.filter(e => e !== g.boss); g.boss = null; }
    g.setPreset('winter'); c.setWinter(true); c.setLightStolen(true); g.minimap.rebuild(true); g.audio.setWind(true); g.equip.escudo = null; g.applyEquip(); g.villagersVisible(true);
    g.npcs.maite.moveTo(27, 8.5); g.npcs.ferreiro.moveTo(24.5, 9.5); g.npcs.guarda.moveTo(64, 3.5); g.npcs.pipo.moveTo(-4, 9); g.npcs.cozinheira.moveTo(-30, 9);
    g.placeWinterProps();
    if (save) g.loadSave(save); else { p.teleport(-18, 50, Math.PI); p.frozen = true; }
    p.dead = false; p.leftItem = 'torch'; p.cold = 0; p.hp = Math.max(p.hp, 40);
    await h.fade(0, 3.5);
    if (!save) { h.chapter('CAPÍTULO II', 'O Inverno Retorna'); await wait(3500); h.bigTitle(6500); g.audio.chime(); await wait(3000); p.frozen = false; }
    if (!this.flags.talkedMaite2) { this.objective('Fale com Maite, na forja', g.npcs.maite.pos); await this.waitUntil(() => this.flags.talkedMaite2); g.save(); }
    this.objective('Siga as marcas de fumaça negra pela estrada do leste até a Floresta Congelada', c.forestGate);
    h.toast('Dica: fogueiras aquecem, curam e salvam o jogo', 5000);
    await this.waitUntil(() => p.pos.x > c.forestGate.x - 2 && Math.abs(p.pos.z) < 10);
    this.finish();
  }
  finish() { const g = this.game, p = g.player; this.objective('Explore o vale congelado', null); g.input.unlock(); document.getElementById('end-stats').innerHTML = `Golpes acertados: ${p.stats.hits}<br>Monstros derrotados: ${p.stats.kills || 0} (lobos: ${p.stats.wolves})<br>Baús abertos: ${p.stats.chests}`; document.getElementById('end').style.display = 'flex'; }
}
