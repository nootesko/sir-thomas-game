// Tile world (Tibia-like): a grid of terrain tiles drawn as chunked meshes from one texture atlas, with pixel-edged
// transitions between terrains, plus a walkability grid used by click-to-walk pathfinding.
import * as THREE from 'three';
export const TILE = 2;
export const T = { grass: 0, cobble: 1, dirt: 2, water: 3, plaza: 4, sewer: 5, sewage: 6, soil: 7, planks: 8 };
const PRIORITY = { 0: 1, 1: 3, 2: 2, 3: 6, 4: 4, 5: 3, 6: 6, 7: 2, 8: 5 };   // higher spreads its border over lower
const CELLS = 4, CELL = 128;   // atlas: 4x4 cells of 128px
const DIRS = [[0, -1], [1, 0], [0, 1], [-1, 0], [1, -1], [1, 1], [-1, 1], [-1, -1]];   // N E S W NE SE SW NW (z grows south)
let seed = 99; const rng = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };

// 8 edge masks (N E S W NE SE SW NW) with a jagged pixel boundary, packed in one 4x2 canvas
function buildMasks() {
  const S = 64, c = document.createElement('canvas'); c.width = S * 4; c.height = S * 2; const x = c.getContext('2d'); const img = x.createImageData(S * 4, S * 2); const d = img.data;
  const noise = []; for (let i = 0; i < S; i++) noise.push(Math.floor(rng() * 7) - 3);
  for (let k = 0; k < 8; k++) { const ox = (k % 4) * S, oy = Math.floor(k / 4) * S; const [dx, dz] = DIRS[k];
    for (let py = 0; py < S; py++) for (let px = 0; px < S; px++) { let on;
      const q = (px >> 2) & 15, qy = (py >> 2) & 15; const nx = noise[q] * 1.2, nz = noise[qy] * 1.2;
      if (k < 4) { const depth = 22; on = dx === 1 ? px > S - depth + nz : dx === -1 ? px < depth + nz : dz === 1 ? py > S - depth + nx : py < depth + nx; }
      else { const r = 16; const cx = dx === 1 ? S : 0, cy = dz === 1 ? S : 0; on = Math.hypot(px - cx, py - cy) < r + noise[q] * 0.8; }
      const i = ((oy + py) * S * 4 + ox + px) * 4; d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = on ? 255 : 0; } }
  x.putImageData(img, 0, 0); return c;
}

export class TileMap {
  constructor(scene, world) {
    this.scene = scene; this.world = world; this.N = Math.round(world * 2 / TILE); this.terrain = new Uint8Array(this.N * this.N); this.walk = new Uint8Array(this.N * this.N); this.meshes = [];
    this.atlas = document.createElement('canvas'); this.atlas.width = this.atlas.height = CELLS * CELL; this.atlasTex = new THREE.CanvasTexture(this.atlas); this.atlasTex.magFilter = this.atlasTex.minFilter = THREE.NearestFilter; this.atlasTex.generateMipmaps = false; this.atlasTex.colorSpace = THREE.SRGBColorSpace;
    this.maskTex = new THREE.CanvasTexture(buildMasks()); this.maskTex.magFilter = this.maskTex.minFilter = THREE.NearestFilter; this.maskTex.generateMipmaps = false; this.maskTex.channel = 1;
    this.baseMat = new THREE.MeshLambertMaterial({ map: this.atlasTex }); this.edgeMat = new THREE.MeshLambertMaterial({ map: this.atlasTex, alphaMap: this.maskTex, alphaTest: 0.5 });
  }
  // ---- grid helpers ----
  toTile(v) { return Math.floor((v + this.world) / TILE); }
  center(i) { return -this.world + i * TILE + TILE / 2; }
  snap(v) { return this.center(Math.max(0, Math.min(this.N - 1, this.toTile(v)))); }
  get(ix, iz) { return ix < 0 || iz < 0 || ix >= this.N || iz >= this.N ? -1 : this.terrain[iz * this.N + ix]; }
  at(x, z) { return this.get(this.toTile(x), this.toTile(z)); }
  fillRect(x0, z0, x1, z1, t) { for (let iz = Math.max(0, this.toTile(z0)); iz <= Math.min(this.N - 1, this.toTile(z1 - 0.01)); iz++) for (let ix = Math.max(0, this.toTile(x0)); ix <= Math.min(this.N - 1, this.toTile(x1 - 0.01)); ix++) this.terrain[iz * this.N + ix] = t; }
  fillCircle(cx, cz, r, t) { for (let iz = this.toTile(cz - r); iz <= this.toTile(cz + r); iz++) for (let ix = this.toTile(cx - r); ix <= this.toTile(cx + r); ix++) if (ix >= 0 && iz >= 0 && ix < this.N && iz < this.N && Math.hypot(this.center(ix) - cx, this.center(iz) - cz) < r) this.terrain[iz * this.N + ix] = t; }
  // walkability from the city's colliders (used only for path planning; live moves still ask the city)
  rasterize(colliders, pad = 0.4) {
    for (const c of colliders) {
      if (c.type === 'box') { for (let iz = Math.max(0, this.toTile(c.minZ - pad)); iz <= Math.min(this.N - 1, this.toTile(c.maxZ + pad)); iz++) for (let ix = Math.max(0, this.toTile(c.minX - pad)); ix <= Math.min(this.N - 1, this.toTile(c.maxX + pad)); ix++) { const x = this.center(ix), z = this.center(iz); if (x > c.minX - pad && x < c.maxX + pad && z > c.minZ - pad && z < c.maxZ + pad) this.walk[iz * this.N + ix] = 1; } }
      else { const r = c.r + pad; for (let iz = Math.max(0, this.toTile(c.z - r)); iz <= Math.min(this.N - 1, this.toTile(c.z + r)); iz++) for (let ix = Math.max(0, this.toTile(c.x - r)); ix <= Math.min(this.N - 1, this.toTile(c.x + r)); ix++) if (Math.hypot(this.center(ix) - c.x, this.center(iz) - c.z) < r) this.walk[iz * this.N + ix] = 1; }
    }
  }
  walkable(ix, iz) { return ix >= 0 && iz >= 0 && ix < this.N && iz < this.N && !this.walk[iz * this.N + ix] && this.terrain[iz * this.N + ix] !== T.water && this.terrain[iz * this.N + ix] !== T.sewage; }
  // A* on the grid, 8 directions, no corner cutting, bounded search window; returns tile centers [[x,z],...]
  findPath(fx, fz, tx, tz, limit = 48) {
    const sx = this.toTile(fx), sz = this.toTile(fz); let gx = this.toTile(tx), gz = this.toTile(tz);
    if (!this.walkable(gx, gz)) { let best = null, bd = 9; for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) { const d = Math.hypot(dx, dz); if (this.walkable(gx + dx, gz + dz) && d < bd) { bd = d; best = [gx + dx, gz + dz]; } } if (!best) return null; [gx, gz] = best; }
    if (Math.abs(gx - sx) > limit || Math.abs(gz - sz) > limit) return null;
    const key = (x, z) => x + z * this.N; const open = new Map(), came = new Map(), g = new Map(); const h = (x, z) => Math.max(Math.abs(x - gx), Math.abs(z - gz));
    open.set(key(sx, sz), [sx, sz, h(sx, sz)]); g.set(key(sx, sz), 0); const closed = new Set(); let it = 0;
    while (open.size && it++ < 6000) {
      let bk = null, bn = null; for (const [k, n] of open) if (!bn || n[2] < bn[2]) { bk = k; bn = n; } open.delete(bk); closed.add(bk); const [cx, cz] = bn;
      if (cx === gx && cz === gz) { const path = []; let k = bk; while (came.has(k)) { const [px, pz] = came.get(k); path.push([this.center(k % this.N), this.center(Math.floor(k / this.N))]); k = key(px, pz); } return path.reverse(); }
      for (const [dx, dz] of DIRS) { const nx = cx + dx, nz = cz + dz; if (!this.walkable(nx, nz)) continue; if (dx && dz && (!this.walkable(cx + dx, cz) || !this.walkable(cx, cz + dz))) continue;
        const nk = key(nx, nz); if (closed.has(nk)) continue; const ng = g.get(bk) + (dx && dz ? 1.41 : 1); if (ng < (g.get(nk) ?? Infinity)) { g.set(nk, ng); came.set(nk, [cx, cz]); open.set(nk, [nx, nz, ng + h(nx, nz)]); } }
    }
    return null;
  }
  // ---- rendering ----
  paintAtlas(images) {   // images: { terrainId: canvas/img }
    const x = this.atlas.getContext('2d'); x.imageSmoothingEnabled = false; x.clearRect(0, 0, this.atlas.width, this.atlas.height);
    for (const [t, img] of Object.entries(images)) { const i = +t; x.drawImage(img, (i % CELLS) * CELL, Math.floor(i / CELLS) * CELL, CELL, CELL); }
    this.atlasTex.needsUpdate = true;
  }
  uvCell(t) { const u0 = (t % CELLS) / CELLS, v0 = 1 - (Math.floor(t / CELLS) + 1) / CELLS; return [u0, v0, u0 + 1 / CELLS, v0 + 1 / CELLS]; }
  build() {
    for (const m of this.meshes) this.scene.remove(m); this.meshes = [];
    const CH = 40, pad = 0.0005;
    for (let cz = 0; cz < this.N; cz += CH) for (let cx = 0; cx < this.N; cx += CH) {
      const base = { p: [], uv: [], n: [] }, edge = { p: [], uv: [], uv1: [], n: [] };
      const quad = (o, x0, z0, x1, z1, y, [u0, v0, u1, v1], m) => { o.p.push(x0, y, z0, x0, y, z1, x1, y, z0, x1, y, z0, x0, y, z1, x1, y, z1); o.uv.push(u0 + pad, v1 - pad, u0 + pad, v0 + pad, u1 - pad, v1 - pad, u1 - pad, v1 - pad, u0 + pad, v0 + pad, u1 - pad, v0 + pad); for (let i = 0; i < 6; i++) o.n.push(0, 1, 0); if (m) o.uv1.push(m[0], m[3], m[0], m[1], m[2], m[3], m[2], m[3], m[0], m[1], m[2], m[1]); };
      for (let iz = cz; iz < Math.min(this.N, cz + CH); iz++) for (let ix = cx; ix < Math.min(this.N, cx + CH); ix++) {
        const t = this.terrain[iz * this.N + ix]; const x0 = -this.world + ix * TILE, z0 = -this.world + iz * TILE;
        quad(base, x0, z0, x0 + TILE, z0 + TILE, 0, this.uvCell(t));
        // transitions: each neighbour of higher priority paints its border over this tile
        for (let k = 0; k < 8; k++) { const nt = this.get(ix + DIRS[k][0], iz + DIRS[k][1]); if (nt < 0 || nt === t || PRIORITY[nt] <= PRIORITY[t]) continue;
          if (k >= 4) { const a = this.get(ix + DIRS[k][0], iz), b = this.get(ix, iz + DIRS[k][1]); if (a === nt || b === nt) continue; }   // corner only when no straight edge already covers it
          const mu0 = (k % 4) / 4, mv0 = 1 - (Math.floor(k / 4) + 1) / 2; quad(edge, x0, z0, x0 + TILE, z0 + TILE, 0.01 + k * 0.0005, this.uvCell(nt), [mu0, mv0, mu0 + 0.25, mv0 + 0.5]); }
      }
      const mk = (o, mat, withUv1) => { if (!o.p.length) return; const gg = new THREE.BufferGeometry(); gg.setAttribute('position', new THREE.Float32BufferAttribute(o.p, 3)); gg.setAttribute('uv', new THREE.Float32BufferAttribute(o.uv, 2)); gg.setAttribute('normal', new THREE.Float32BufferAttribute(o.n, 3)); if (withUv1) gg.setAttribute('uv1', new THREE.Float32BufferAttribute(o.uv1, 2)); const m = new THREE.Mesh(gg, mat); m.receiveShadow = true; this.scene.add(m); this.meshes.push(m); };
      mk(base, this.baseMat, false); mk(edge, this.edgeMat, true);
    }
  }
}
