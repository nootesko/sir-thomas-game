import * as THREE from 'three';
import { Assets, ASSET_NAMES, sliceSheet } from './assets.js';
import * as S from './sprites.js';
import * as PX from './pixel.js';
import { Sky } from './sky.js';
import { Player } from './player.js';
import { Overlay } from './overlay.js';
import { Minimap } from './minimap.js';
import { Input } from './input.js';
import { HUD } from './hud.js';
import { Audio } from './audio.js';
import { Story } from './story.js';
import { NPC, Boss, Prop } from './entities.js';
import { Monster, Loot, MONSTERS } from './monsters.js';
import { ITEMS, SLOTS, sellPrice } from './items.js';
import { City, WALL, SEWER } from './city.js';
import { VIEW } from './view.js';

const PIXEL = 1;
const S_GRATE = (() => { const [c, x] = S.canvas(16, 16); x.fillStyle = '#2a2a30'; x.beginPath(); x.arc(8, 8, 7, 0, 7); x.fill(); x.fillStyle = '#55555f'; for (let i = 2; i < 14; i += 3) x.fillRect(i, 3, 1, 10); return c; })();
const S_LADDER = (() => { const [c, x] = S.canvas(10, 24); x.fillStyle = '#6b4423'; x.fillRect(1, 0, 2, 24); x.fillRect(7, 0, 2, 24); for (let y = 2; y < 24; y += 4) x.fillRect(1, y, 8, 1); return c; })();
class Game {
  constructor() {
    this.canvas = document.getElementById('scene');
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: false, powerPreference: 'high-performance' });
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFShadowMap; this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.scene = new THREE.Scene(); this.camera = new THREE.PerspectiveCamera(VIEW.fov, 1, 0.1, 900); this.scene.add(this.camera);
    this.resize(); window.addEventListener('resize', () => this.resize());
    this.input = new Input(this.canvas); this.audio = new Audio();
    this.city = new City(this.scene); this.sky = new Sky(this.scene);
    this.lantern = new THREE.PointLight(0xffb060, 0, 16, 1.6); this.scene.add(this.lantern);
    this.player = new Player(this); this.overlay = new Overlay(document.getElementById('overlay'));
    this.minimap = new Minimap(this.city, document.getElementById('minimap'), document.getElementById('bigmap'));
    this.hud = new HUD(this); this.story = new Story(this);
    this.entities = []; this.npcs = {}; this.boss = null; this.flash = 0; this.running = false; this.time = 0; this.bigmap = false;
    this.equip = { espada: 'real', escudo: 'reino', armadura: 'roupa', elmo: null, capa: null, botas: null, amuleto: null, anel: null };
    this.buildNPCs(); this.spawnMonsters(); this.applyEquip();
    document.getElementById('minimap-wrap').addEventListener('click', e => { e.stopPropagation(); if (this.running) this.toggleMap(true); });
    document.getElementById('bigmap-wrap').addEventListener('click', () => this.toggleMap(false, true));
    const save = (() => { try { return JSON.parse(localStorage.getItem('fortaleza25d-save')); } catch (e) { return null; } })();
    if (save) document.getElementById('btn-continue').style.display = '';
    document.getElementById('btn-new').onclick = () => this.start(null);
    document.getElementById('btn-continue').onclick = () => this.start(save);
    document.getElementById('btn-end-continue').onclick = () => { document.getElementById('end').style.display = 'none'; this.input.lock(); };
    this.clock = new THREE.Clock(); this.loop();
  }
  resize() { const w = this.canvas.parentElement.clientWidth || window.innerWidth, h = this.canvas.parentElement.clientHeight || window.innerHeight; this.renderer.setSize(Math.floor(w / PIXEL), Math.floor(h / PIXEL), false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
  toggleMap(open = !this.bigmap, relock = false) {
    if (this.hud.busy || open === this.bigmap) return; this.bigmap = open;
    document.getElementById('bigmap-wrap').style.display = open ? 'flex' : 'none'; this.player.frozen = open;
    if (open) this.input.unlock(); else if (relock) this.input.lock();
  }
  setPreset(name) { this.sky.setPreset(name); this.city.setNight(name === 'night'); }
  // ---------- population ----------
  buildNPCs() {
    const s = this.story; const mk = (id, name, x, z, sprite, asset, color = '#fff') => { const n = new NPC(this, { id, name, x, z, sprite, asset, color, dialog: () => s.npcDialog(id) }); this.npcs[id] = n; this.entities.push(n); return n; };
    mk('maite', 'Princesa Maite', 3.5, 5, S.human({ hair: '#5a2d12', tunic: '#d9a1c9', legs: '#b07aa0', crown: true, trim: '#f6c12e' }), 'sprite_maite', '#f6c12e');
    mk('ferreiro', 'Ferreiro Bruno', 27, 8.5, S.human({ hair: '#2a1a0a', tunic: '#6b4a2a', apron: true }), 'sprite_ferreiro');
    mk('cozinheira', 'Dona Rosa', -30, 8.5, S.human({ hair: '#888', tunic: '#c94a3f', apron: true }), 'sprite_cozinheira');
    mk('guarda', 'Guarda Olavo', 64, 3.5, S.human({ hair: '#2a1a0a', tunic: '#9ea6b5', helmet: true, trim: '#9ea6b5', legs: '#2b5fc7' }), 'sprite_guarda');
    mk('pipo', 'Pipo', -5, -9, S.human({ hair: '#d9a441', tunic: '#5fae45', legs: '#3a5a2a' }), 'sprite_pipo');
    mk('mercador', 'Mercador Gaspar', -20, 4, S.human({ hair: '#2a1a0a', tunic: '#7a3a9a', legs: '#3a2a4a', trim: '#f6c12e' }), 'sprite_mercador', '#ffe066');
    // villagers wandering the streets
    const looks = [{ hair: '#2a1a0a', tunic: '#7a4a9a' }, { hair: '#d9a441', tunic: '#3a7a4a' }, { hair: '#888', tunic: '#8a5a2e' }, { hair: '#5a2d12', tunic: '#2b5fc7' }, { hair: '#3a2a1a', tunic: '#c94a3f', apron: true }, { hair: '#d9a441', tunic: '#d9a1c9' }, { hair: '#2a1a0a', tunic: '#5fae45' }, { hair: '#888', tunic: '#9a7a4a' }];
    const paths = [[[14, 2], [50, 2], [50, -2], [14, -2]], [[-14, 2], [-55, 2], [-55, -2], [-14, -2]], [[2, 14], [2, 50], [-2, 50], [-2, 14]], [[2, -14], [2, -34], [-2, -34], [-2, -14]], [[12, 12], [-12, 12], [-12, -12], [12, -12]], [[36, 10], [36, 60], [40, 60], [40, 10]], [[-36, -10], [-36, -60], [-40, -60], [-40, -10]], [[10, 36], [60, 36], [60, 40], [10, 40]]];
    const sheet = Assets.has('sprite_villagers_sheet') ? sliceSheet(Assets.images.sprite_villagers_sheet, 6) : null;
    this.villagers = looks.map((lk, i) => { const n = new NPC(this, { id: 'vil' + i, name: null, x: paths[i][0][0], z: paths[i][0][1], sprite: sheet ? sheet[i % sheet.length] : S.human(lk), dialog: () => s.npcDialog('vil'), kind: 'villager', path: paths[i] }); n.pi = 1; this.entities.push(n); return n; });
  }
  spawnMonsters() {
    const X = WALL, add = (id, list) => list.forEach(([x, z]) => this.entities.push(new Monster(this, id, x, z)));
    add('coelho', [[X + 18, 14], [X + 26, -16], [X + 40, 22], [X + 55, -24], [X + 30, 40], [-20, -95], [20, -100], [-90, 30], [-95, -40], [40, 95]]);
    add('abelha', [[X + 35, 30], [X + 50, 34], [X + 70, -30], [X + 22, -34], [-60, -100], [60, 100]]);
    add('serpente', [[-120, 40], [-115, -50], [-125, 90], [X + 90, 45], [X + 85, -45], [30, 120]]);
    add('lobo', [[X + 120, -40], [X + 135, 30], [X + 150, -25], [X + 110, 60], [-100, 140], [-60, -150], [100, -140]]);
    const S = SEWER, R = (a, b) => a + Math.random() * (b - a); const rooms = [[S.x0 + 20, S.z0 + 20], [S.x0 + 60, S.z0 + 25], [S.x1 - 25, S.z0 + 30], [S.x0 + 25, S.z0 + 60], [S.x1 - 30, S.z0 + 60], [S.x0 + 40, S.z0 + 85], [S.x1 - 20, S.z0 + 100], [S.x0 + 30, S.z1 - 25], [S.x1 - 40, S.z1 - 25], [S.x0 + 70, S.z0 + 115]];
    for (const [x, z] of rooms) { add('rato', [[x + R(-4, 4), z + R(-4, 4)], [x + R(-4, 4), z + R(-4, 4)]]); add('barata', [[x + R(-5, 5), z + R(-5, 5)], [x + R(-5, 5), z + R(-5, 5)], [x + R(-5, 5), z + R(-5, 5)]]); }
    // sewer grate in the city and the ladder back up
    this.entities.push(new Prop(this, { kind: 'grate', x: S.grate[0], z: S.grate[1], w: 1.6, h: 1.0, src: Assets.src('prop_sewer_grate', S_GRATE), yOff: 0.05, collide: false, flat: true }));
    this.entities.push(new Prop(this, { kind: 'ladder', x: S.entry[0], z: S.entry[1], w: 1.2, h: 2.4, src: Assets.src('prop_ladder', S_LADDER), collide: false }));
  }
  spawnLoot(pos, items, gold) { const R = () => (Math.random() - 0.5) * 1.6; for (const id of items) this.entities.push(new Loot(this, pos.x + R(), pos.z + R(), id, 1)); if (gold > 0) this.entities.push(new Loot(this, pos.x + R(), pos.z + R(), null, 0, gold)); }
  // ---------- inventory & trade ----------
  addItem(id, qty = 1) { const p = this.player; p.inventory[id] = (p.inventory[id] || 0) + qty; this.hud.toast(`+${qty} ${ITEMS[id].name}`, 1500); this.hud.refreshPanels(); }
  removeItem(id, qty = 1) { const p = this.player; if ((p.inventory[id] || 0) < qty) return false; p.inventory[id] -= qty; if (p.inventory[id] <= 0) delete p.inventory[id]; this.hud.refreshPanels(); return true; }
  addGold(n) { this.player.gold += n; this.hud.toast(`+${n} moedas`, 1500); this.hud.refreshPanels(); }
  useItem(id) {
    const it = ITEMS[id], p = this.player; if (!it || !p.inventory[id]) return;
    if (it.consumable) { this.removeItem(id); if (it.food) { p.regenPool += it.stats.vida || 0; if (it.warm) p.cold = 0; this.hud.toast(`${it.name}: recuperando vida aos poucos`); } else { p.heal(it.stats.vida || 0); this.hud.toast(`${it.name}: +${it.stats.vida} de vida`); } this.audio.pickup(); }
    else if (it.slot) { this.removeItem(id); const old = this.equip[it.slot]; this.equip[it.slot] = id; if (old) { p.inventory[old] = (p.inventory[old] || 0) + 1; } this.applyEquip(); this.hud.toast(`${it.name} equipado`); this.hud.refreshPanels(); }
  }
  unequip(slot) { const id = this.equip[slot]; if (!id || slot === 'espada') return; this.equip[slot] = null; this.player.inventory[id] = (this.player.inventory[id] || 0) + 1; this.applyEquip(); this.hud.refreshPanels(); }
  buy(id) { const it = ITEMS[id], p = this.player; if (p.gold < it.price) { this.hud.toast('Moedas insuficientes'); return; } p.gold -= it.price; p.inventory[id] = (p.inventory[id] || 0) + 1; this.audio.pickup(); this.hud.toast(`Comprou ${it.name}`); this.hud.refreshPanels(); this.save(); }
  sell(id) { const it = ITEMS[id], p = this.player; if (!this.removeItem(id)) return; p.gold += sellPrice(it); this.audio.pickup(); this.hud.toast(`Vendeu ${it.name} por ${sellPrice(it)}`); this.hud.refreshPanels(); this.save(); }
  villagersVisible(v) { for (const n of this.villagers) { n.mesh.visible = v; n.hidden = !v; } }
  guardsRun() { const g = new NPC(this, { id: 'g2', name: null, x: 30, z: 3, sprite: S.human({ hair: '#2a1a0a', tunic: '#9ea6b5', helmet: true, trim: '#9ea6b5', legs: '#2b5fc7' }), kind: 'villager', path: [[8, 3], [3, -20], [4, -36], [30, 3]] }); g.speed = 6; this.entities.push(g); }
  placeWinterProps() {
    if (this.winterPlaced) return; this.winterPlaced = true; const c = this.city; const X = WALL;
    const chest = [Assets.src('prop_chest_closed', S.CHEST), Assets.src('prop_chest_open', S.CHEST_OPEN)];
    [[X + 20, -12, 'capa'], [X + 45, 14, 'sopa'], [X + 80, -16, 'botas'], [X + 130, 18, 'glacial'], [X + 60, -45, 'elmo'], [X + 110, 40, 'amuleto']].forEach(([x, z, item]) => this.entities.push(new Prop(this, { kind: 'chest', x, z, w: 1.6, h: 1.2, src: chest, item })));
    const fire = [Assets.src('prop_campfire_off', S.FIRE_OFF), ...(Assets.has('prop_campfire_lit') ? [Assets.images.prop_campfire_lit] : S.FIRE)];
    [[-8, 20, true], [X + 30, 7, false], [X + 85, -8, false], [X + 140, 8, false]].forEach(([x, z, lit]) => this.entities.push(new Prop(this, { kind: 'fire', x, z, w: 1.8, h: 2, src: fire, lit })));
    [[X + 38, -9, 'sword', 'Espada Quebrada', '"Pertenceu a um cavaleiro que tentou atravessar o vale quando o inverno ainda dominava estas terras. Ele nunca chegou à floresta."'], [X + 100, 12, 'statue', 'Estátua Sem Rosto', '"Alguém esculpiu esta figura antes de a Fortaleza existir. Os braços estão erguidos, como se segurassem algo que brilhava."'], [X + 70, 30, 'toy', 'Brinquedo de Madeira', '"Um cavalinho de madeira, esquecido na neve. Alguma criança do vale brincava aqui quando ainda havia sol."']].forEach(([x, z, kind, title, text]) => this.entities.push(new Prop(this, { kind: 'lore', x, z, w: kind === 'statue' ? 1.6 : 1.1, h: kind === 'statue' ? 2.4 : 1.3, src: S.LORE[kind], title, text })));
    [[X + 25, -14], [X + 40, 16], [X + 58, -8], [X + 72, 14], [X + 90, -14], [X + 105, 10], [X + 120, -18], [X + 135, 12], [X + 150, -8], [X + 165, 10], [X + 60, -40], [X + 100, 36]].forEach(([x, z]) => this.entities.push(new Monster(this, 'lobo_gelo', x, z)));
    this.entities.push(new Prop(this, { kind: 'prop', x: 25, z: 6.5, w: 1.2, h: 0.9, src: S.SHIELD_BROKEN, yOff: 1.1, collide: false }));
  }
  spawnBoss() { this.boss = new Boss(this, this.city.lightPos); this.entities.push(this.boss); }
  applyEquip() {
    const p = this.player; p.damage = 10 + p.attr.ataque * 2; p.defense = p.attr.defesa; p.coldResist = 0; let maxHp = 100 + (p.level - 1) * 8; p.sword = 'real'; p.swingTime = 0.4 / (1 + p.attr.velocidade * 0.06);
    for (const s of SLOTS) { const it = this.equip[s] && ITEMS[this.equip[s]]; if (!it) continue; p.damage += it.stats.dano || 0; p.defense += it.stats.defesa || 0; p.coldResist += (it.stats.frio || 0) / 100; maxHp += it.stats.vida || 0; if (it.sword) p.sword = it.sword; }
    p.coldResist = Math.min(0.85, p.coldResist); if (p.maxHp !== maxHp) { p.hp = Math.min(maxHp, p.hp + Math.max(0, maxHp - p.maxHp)); p.maxHp = maxHp; }
    this.hud.refreshEquip(this.equip); this.hud.refreshPanels();
  }
  async start(save) { this.audio.init(); document.getElementById('menu').style.display = 'none'; this.running = true; this.input.lock(); this.story.run(save).catch(e => console.error(e)); }
  // ---------- save ----------
  save() { const p = this.player; const data = { x: p.pos.x, z: p.pos.z, yaw: p.yaw, hp: p.hp, equip: this.equip, talkedMaite2: !!this.story.flags.talkedMaite2, opened: this.entities.filter(e => e.kind === 'chest' && e.opened).map(e => [e.pos.x, e.pos.z]), lit: this.entities.filter(e => e.kind === 'fire' && e.lit).map(e => [e.pos.x, e.pos.z]), stats: p.stats, level: p.level, xp: p.xp, points: p.points, attr: p.attr, gold: p.gold, inventory: p.inventory }; try { localStorage.setItem('fortaleza25d-save', JSON.stringify(data)); } catch (e) {} }
  loadSave(s) { const p = this.player; p.teleport(s.x, s.z, s.yaw); p.hp = s.hp; this.equip = { ...this.equip, ...s.equip }; this.equip.escudo = null; this.applyEquip(); p.stats = { ...p.stats, ...(s.stats || {}) }; p.level = s.level || 1; p.xp = s.xp || 0; p.points = s.points || 0; p.attr = { ...p.attr, ...(s.attr || {}) }; p.gold = s.gold || 0; p.inventory = s.inventory || {}; this.applyEquip(); this.story.flags.talkedMaite2 = !!s.talkedMaite2; const k = (a, b) => Math.round(a) + ',' + Math.round(b); const op = new Set((s.opened || []).map(([x, z]) => k(x, z))), lt = new Set((s.lit || []).map(([x, z]) => k(x, z))); for (const e of this.entities) { if (e.kind === 'chest' && op.has(k(e.pos.x, e.pos.z))) e.opened = true; if (e.kind === 'fire' && lt.has(k(e.pos.x, e.pos.z))) e.lit = true; } }
  // ---------- events ----------
  onPlayerDeath() {
    const p = this.player, h = this.hud; p.frozen = true; h.toast('Thomas caiu...', 3000);
    (async () => { await h.fade(1, 1.5); await new Promise(r => setTimeout(r, 800));
      let best = null, bd = 1e9; for (const e of this.entities) if (e.kind === 'fire' && e.lit) { const d = e.pos.distanceTo(p.pos); if (d < bd) { bd = d; best = e; } }
      if (best) p.teleport(best.pos.x + 2, best.pos.z + 2); else if (this.story.chapter === 'night') p.teleport(0, -30, 0); else p.teleport(-18, 50, Math.PI);
      p.hp = p.maxHp; p.cold = 0; p.dead = false; p.frozen = false;
      for (const e of this.entities) if (e.kind === 'monster' && e.alive) { e.state = 'idle'; e.pos.copy(e.home); e.hp = e.cfg.hp; }
      if (this.boss && this.boss.phase === 'fight') { this.boss.fightT = 0; this.boss.swoop = null; this.boss.cool = 3; }
      await h.fade(0, 1.5); })();
  }
  onBossCharge() { this.hud.toast('A fumaça negra vem contra você — LEVANTE O ESCUDO! (botão direito)', 3500); this.player.canAttack = false; }
  onBossBlast() { const p = this.player, h = this.hud; setTimeout(() => { if (p.blocking) { h.toast('O escudo se parte!', 2500); this.audio.block(); } else { h.toast('A fumaça atinge Thomas em cheio!', 2500); p.hp = Math.max(1, p.hp - 35); p.hurtT = 0.6; } p.shieldCrack = true; p.shake = 2; }, 700); this.player.canAttack = true; }
  // ---------- interaction ----------
  findInteractable() {
    const p = this.player, c = this.city, st = this.story, f = p.forward; let best = null, bd = 3.4;
    const consider = (pos, r, label, use) => { const to = pos.clone().sub(p.pos).setY(0); const d = to.length(); if (d < bd + r && (d < 2.2 || to.normalize().dot(f) > 0.2)) { bd = d; best = { label, use }; } };
    for (const e of this.entities) {
      if ((e.kind === 'npc' || e.kind === 'villager') && e.dialog && !e.hidden && !(e.kind === 'villager' && this.story.chapter === 'night')) consider(e.pos, 0.6, `<b>E</b> — Falar${e.name ? ' com ' + e.name : ''}`, () => e.dialog());
      if (e.kind === 'chest' && !e.opened) consider(e.pos, 0.8, '<b>E</b> — Abrir baú', async () => { e.opened = true; p.stats.chests++; const it = ITEMS[e.item]; const choice = await this.hud.card(it); if (choice === 'equip') { if (it.consumable) { p.heal(it.stats.vida || 0); p.cold = 0; this.hud.toast('Thomas toma a sopa quente. +vida, frio zerado'); } else { this.equip[it.slot] = it.id; this.applyEquip(); this.hud.toast(`${it.name} equipado`); } } else { p.inventory[it.id] = (p.inventory[it.id] || 0) + 1; this.hud.toast(`${it.name} guardado no inventário`); } this.save(); });
      if (e.kind === 'fire') consider(e.pos, 0.9, e.lit ? '<b>E</b> — Descansar na fogueira' : '<b>E</b> — Acender fogueira', async () => { if (!e.lit) { e.lit = true; this.audio.fire(); } p.heal(p.maxHp); p.cold = 0; p.frozen = true; this.hud.toast('🔥 Thomas esquenta as mãos. Jogo salvo.', 3000); await this.hud.fade(0.6, 0.8); await new Promise(r => setTimeout(r, 1200)); await this.hud.fade(0, 0.8); p.frozen = false; this.save(); });
      if (e.kind === 'lore') consider(e.pos, 0.7, '<b>E</b> — Examinar', () => this.hud.lore(e.title, e.text));
      if (e.kind === 'grate') consider(e.pos, 0.9, '<b>E</b> — Descer ao esgoto', () => this.travel(SEWER.entry[0] + 1.5, SEWER.entry[1] + 1.5, 'Esgoto da Fortaleza'));
      if (e.kind === 'ladder') consider(e.pos, 0.9, '<b>E</b> — Subir a escada', () => this.travel(SEWER.grate[0] + 1.5, SEWER.grate[1], null));
    }
    if (st.flags.canSleep && !st.flags.slept) consider(c.bedPos, 1.2, '<b>E</b> — Dormir', () => { st.flags.slept = true; });
    return best;
  }
  async travel(x, z, label) { const p = this.player, h = this.hud; p.frozen = true; await h.fade(1, 0.6); p.teleport(x, z); if (label) h.toast(label, 2500); await h.fade(0, 0.8); p.frozen = false; }
  // ---------- loop ----------
  loop() {
    requestAnimationFrame(() => this.loop());
    const dt = Math.min(0.05, this.clock.getDelta()); this.time += dt;
    if (this.running) {
      const p = this.player, h = this.hud, inp = this.input; h.update();
      if (inp.pressed.KeyM && !h.busy) this.toggleMap();
      if ((inp.pressed.KeyI || inp.pressed.KeyC) && !this.bigmap) h.togglePanel(inp.pressed.KeyC ? 'attr' : 'inv');
      if (inp.pressed.Escape) { if (this.bigmap) this.toggleMap(false); else h.closePanel(); }
      this.flash = Math.max(0, this.flash - dt * 1.2);
      p.update(dt);
      for (const e of this.entities) e.update(dt); this.entities = this.entities.filter(e => !e.removed);
      this.city.faceAll(); this.city.fadeNear(p.pos.x, p.pos.z, dt); this.city.update(dt, this.time); this.sky.update(p.pos);
      this.lantern.position.set(p.pos.x, 1.6, p.pos.z);
      this.lantern.intensity = (this.city.inSewer(p.pos.x, p.pos.z) ? 12 : this.sky.name === 'night' ? 10 : this.sky.name === 'winter' ? 3 : 0) + (p.leftItem === 'torch' ? 6 + Math.sin(this.time * 12) * 1.5 : 0);
      const busy = h.busy || p.frozen || p.dead; const it = busy ? null : this.findInteractable(); h.hint(it ? it.label : null);
      if (it && inp.pressed.KeyE) { inp.pressed.KeyE = false; it.use(); }
      h.bars(p, this.city.winter); h.region(this.city.regionAt(p.pos.x, p.pos.z));
      const t = this.story.target; h.distance(t ? Math.round(Math.hypot(t.x - p.pos.x, t.z - p.pos.z)) + ' m' : null);
      this.minimap.draw(this); if (this.bigmap) this.minimap.drawBig(this);
      this.overlay.draw(p, this, dt);
    }
    this.renderer.render(this.scene, this.camera);
    this.input.endFrame();
  }
}
Assets.preload(ASSET_NAMES).then(() => {
  if (Assets.has('ui_logo')) { for (const id of ['menu', 'bigtitle']) { const el = document.getElementById(id); const img = document.createElement('img'); img.src = 'assets/ui_logo.png'; img.className = 'logo'; const t1 = el.querySelector('.mt1, .t1'), t2 = el.querySelector('.mt2, .t2'); if (t1) t1.replaceWith(img); if (t2) t2.remove(); } }
  if (Assets.has('ui_card_frame')) { const card = document.getElementById('card'); card.classList.add('framed'); }
  window.game = new Game();
});
