// Fixed top-down camera (Tibia-like): north is always up. Sprites lean back (negative tilt) so they face the camera instead of being foreshortened.
export const VIEW = { yaw: 0, pitch: 1.2, tilt: -0.55, dist: 20, minDist: 12, maxDist: 34, fov: 42, hands: false };
