import { ITEMS, SLOTS, SLOT_NAMES, SHOPS, sellPrice } from './items.js';
import { iconFor } from './icons.js';
const $ = id => document.getElementById(id);
export class HUD {
  constructor(game) {
    this.game = game; this.dialogResolve = null; this.loreResolve = null; this.cardResolve = null; this.toastT = null;
    this.e = {}; ['objective-text', 'objective-dist', 'region', 'hint', 'toast', 'dialog', 'dialog-name', 'dialog-text', 'lore', 'lore-title', 'lore-text', 'card-wrap', 'card-rarity', 'card-name', 'card-icon', 'card-stats', 'chapter', 'bigtitle', 'fade', 'hp-fill', 'hp-text', 'cold-pill', 'cold-fill', 'equip'].forEach(id => this.e[id] = $(id));
    document.addEventListener('mousedown', e => { if (e.button === 0 && this.dialogResolve) this.advanceDialog(); });
    $('card-equip').onclick = () => this.closeCard('equip'); $('card-discard').onclick = () => this.closeCard('discard');
    this.panel = null; this.shopId = null;
    $('btn-inv').onclick = () => this.togglePanel('inv'); $('btn-attr').onclick = () => this.togglePanel('attr'); $('panel-close').onclick = () => this.closePanel(); $('shop-close').onclick = () => this.closePanel();
    this.buildEquip();
  }
  buildEquip() {
    this.slots = {};
    for (const s of SLOTS) { const d = document.createElement('div'); d.className = 'slot empty'; const c = document.createElement('canvas'); c.width = c.height = 16; d.appendChild(c); const n = document.createElement('div'); n.className = 'nm'; n.textContent = SLOT_NAMES[s]; d.appendChild(n); const l = document.createElement('div'); l.className = 'lvl'; d.appendChild(l); d.title = 'Clique para guardar na mochila'; d.style.cursor = 'pointer'; d.onclick = () => this.game.unequip(s); this.e.equip.appendChild(d); this.slots[s] = { d, c, n, l }; }
  }
  refreshEquip(equip) {
    for (const s of SLOTS) { const sl = this.slots[s], it = equip[s] ? ITEMS[equip[s]] : null; const x = sl.c.getContext('2d'); x.clearRect(0, 0, 16, 16);
      if (it) { const ic = iconFor(it.icon); x.imageSmoothingEnabled = false; x.drawImage(ic, 0, 0, 16, 16); sl.d.className = 'slot'; sl.n.textContent = it.name.split(' ')[0]; sl.l.textContent = 'Nv ' + it.lvl; sl.l.style.display = ''; } else { sl.d.className = 'slot empty'; sl.n.textContent = SLOT_NAMES[s]; sl.l.style.display = 'none'; } }
  }
  objective(text) { this.e['objective-text'].textContent = text; }
  distance(d) { this.e['objective-dist'].textContent = d == null ? '' : `${d}`; }
  region(name) { if (this.e.region.textContent !== name) this.e.region.textContent = name; }
  bars(p, winter) { this.e['hp-fill'].style.width = `${Math.max(0, p.hp / p.maxHp * 100)}%`; this.e['hp-text'].textContent = `${Math.ceil(p.hp)}/${p.maxHp}`; this.e['cold-pill'].style.display = winter ? 'flex' : 'none'; this.e['cold-fill'].style.width = `${p.cold * 100}%`; }
  hint(html) { this.e.hint.style.display = html ? 'block' : 'none'; if (html) this.e.hint.innerHTML = html; }
  toast(text, ms = 2200) { this.e.toast.textContent = text; this.e.toast.style.opacity = 1; clearTimeout(this.toastT); this.toastT = setTimeout(() => this.e.toast.style.opacity = 0, ms); }
  dialog(lines) { return new Promise(res => { this.lines = lines.slice(); this.dialogResolve = res; this.game.player.frozen = true; this.e.dialog.style.display = 'block'; this.showLine(); }); }
  showLine() { const [n, t] = this.lines.shift(); this.e['dialog-name'].textContent = n; this.e['dialog-text'].textContent = t; }
  advanceDialog() { if (!this.dialogResolve) return; if (this.lines.length) this.showLine(); else { this.e.dialog.style.display = 'none'; const r = this.dialogResolve; this.dialogResolve = null; this.game.player.frozen = false; this.game.input.pressed = {}; r(); } }
  lore(title, text) { return new Promise(res => { this.loreResolve = res; this.game.player.frozen = true; this.e['lore-title'].textContent = title; this.e['lore-text'].textContent = text; this.e.lore.style.display = 'block'; }); }
  closeLore() { if (!this.loreResolve) return; this.e.lore.style.display = 'none'; const r = this.loreResolve; this.loreResolve = null; this.game.player.frozen = false; r(); }
  card(item) {
    return new Promise(res => { this.cardResolve = res; this.game.player.frozen = true; const e = this.e; e['card-rarity'].textContent = item.rarity.toUpperCase(); e['card-rarity'].className = item.rarity; e['card-name'].textContent = item.name + (item.lvl ? `  Nv ${item.lvl}` : '');
      const x = e['card-icon'].getContext('2d'); x.imageSmoothingEnabled = false; x.clearRect(0, 0, 64, 64); x.drawImage(iconFor(item.icon), 0, 0, 64, 64);
      const names = { dano: 'DANO', defesa: 'DEFESA', frio: 'FRIO', vida: 'VIDA' };
      e['card-stats'].innerHTML = Object.entries(item.stats).map(([k, v]) => `${names[k]}<span>+${v}${k === 'frio' ? '%' : ''}</span>`).join('<br>') + (item.note ? `<br><i>${item.note}</i>` : '') + (item.slot ? `<br><small>Espaço: ${SLOT_NAMES[item.slot]}</small>` : '<br><small>Usar agora</small>');
      $('card-equip').textContent = item.consumable ? 'USAR ▶' : 'EQUIPAR ▶'; e['card-wrap'].className = 'show'; this.game.audio.pickup(); });
  }
  closeCard(choice) { if (!this.cardResolve) return; this.e['card-wrap'].className = ''; const r = this.cardResolve; this.cardResolve = null; this.game.player.frozen = false; r(choice); }
  chapter(small, big, ms = 4500) { this.e.chapter.innerHTML = `<small>${small}</small>${big}`; this.e.chapter.style.opacity = 1; setTimeout(() => this.e.chapter.style.opacity = 0, ms); }
  bigTitle(ms = 6000) { this.e.bigtitle.style.opacity = 1; setTimeout(() => this.e.bigtitle.style.opacity = 0, ms); }
  fade(to, sec = 1, color = '#000') { const f = this.e.fade; f.style.transition = `opacity ${sec}s`; f.style.background = color; f.style.opacity = to; return new Promise(r => setTimeout(r, sec * 1000)); }
  update() {
    const inp = this.game.input;
    if (inp.pressed.KeyE) { if (this.dialogResolve) this.advanceDialog(); else if (this.loreResolve) this.closeLore(); }
    if (this.cardResolve) { if (inp.pressed.ArrowRight || inp.pressed.Digit1 || inp.pressed.KeyE) this.closeCard('equip'); else if (inp.pressed.ArrowLeft || inp.pressed.Digit2) this.closeCard('discard'); }
  }
  get busy() { return !!(this.dialogResolve || this.loreResolve || this.cardResolve || this.panel); }
  // ---------- inventory / attributes / shop panels ----------
  togglePanel(which) { if (this.panel === which || (this.panel === 'inv' && which === 'attr') || (this.panel === 'attr' && which === 'inv')) return this.closePanel(); if (this.dialogResolve || this.loreResolve || this.cardResolve) return; this.openPanel(which); }
  openPanel(which) { this.panel = which; this.game.player.frozen = true; $('panel-ui').classList.toggle('show', which !== 'shop'); $('shop-ui').classList.toggle('show', which === 'shop'); $('panel-title').textContent = which === 'attr' ? 'ATRIBUTOS E MOCHILA' : 'MOCHILA E ATRIBUTOS'; this.refreshPanels(); }
  closePanel() { if (!this.panel) return; this.panel = null; this.shopId = null; this.game.player.frozen = false; $('panel-ui').classList.remove('show'); $('shop-ui').classList.remove('show'); this.game.input.pressed = {}; }
  shop(id) { this.shopId = id; this.openPanel('shop'); $('shop-title').textContent = SHOPS[id].title.toUpperCase(); }
  iconCanvas(name, size) { const c = document.createElement('canvas'); c.width = c.height = 16; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(iconFor(name), 0, 0, 16, 16); return c; }
  refreshPanels() {
    const g = this.game, p = g.player; if (!p) return;
    $('lvl-text').textContent = `Nv ${p.level}`; $('xp-fill').style.width = `${Math.min(100, p.xp / p.xpToNext() * 100)}%`; $('xp-text').textContent = `${p.xp}/${p.xpToNext()}`; $('gold-text').textContent = p.gold; $('btn-attr').style.borderColor = p.points > 0 ? '#f6c12e' : '';
    if (!this.panel) return;
    if (this.panel === 'shop') {
      const shop = SHOPS[this.shopId]; $('shop-gold').textContent = p.gold;
      const row = (it, price, label, onclick, dis, cls = '') => { const d = document.createElement('div'); d.className = 'shop-row ' + cls; d.appendChild(this.iconCanvas(it.icon)); const n = document.createElement('span'); n.className = 'nm'; n.innerHTML = `${it.name}${it.lvl > 1 ? ` <small>Nv ${it.lvl}</small>` : ''}<br><small>${Object.entries(it.stats).map(([k, v]) => `${k} +${v}`).join(' · ')}${it.note ? ' · ' + it.note : ''}</small>`; d.appendChild(n); const pr = document.createElement('span'); pr.className = 'pr'; pr.textContent = `${price} ◎`; d.appendChild(pr); const b = document.createElement('button'); b.textContent = label; b.disabled = dis; b.onclick = onclick; d.appendChild(b); return d; };
      const buy = $('shop-buy'); buy.innerHTML = ''; for (const id of shop.items) { const it = ITEMS[id]; buy.appendChild(row(it, it.price, 'Comprar', () => g.buy(id), p.gold < it.price)); }
      const sell = $('shop-sell'); sell.innerHTML = ''; const ids = Object.keys(p.inventory); if (!ids.length) sell.innerHTML = '<div class="ui-note">A mochila está vazia.</div>';
      for (const id of ids) { const it = ITEMS[id]; sell.appendChild(row(it, sellPrice(it), `Vender (${p.inventory[id]})`, () => g.sell(id), false)); }
      return;
    }
    $('inv-gold').textContent = p.gold; const grid = $('inv-grid'); grid.innerHTML = '';
    const ids = Object.keys(p.inventory); if (!ids.length) grid.innerHTML = '<div class="ui-note">Vazia. Derrote monstros fora da cidade ou compre nas lojas.</div>';
    for (const id of ids) { const it = ITEMS[id]; const d = document.createElement('div'); d.className = 'inv-item'; d.appendChild(this.iconCanvas(it.icon)); const q = document.createElement('span'); q.className = 'q'; q.textContent = p.inventory[id]; d.appendChild(q);
      const tip = document.createElement('div'); tip.className = 'tip'; tip.innerHTML = `<b>${it.name}</b><br>${Object.entries(it.stats).map(([k, v]) => `${k} +${v}`).join(' · ')}${it.note ? '<br><i>' + it.note + '</i>' : ''}<br><small>${it.consumable ? 'Clique para usar' : it.slot ? 'Clique para equipar' : 'Vende por ' + sellPrice(it) + ' moedas'}</small>`; d.appendChild(tip); d.onclick = () => g.useItem(id); grid.appendChild(d); }
    $('attr-points').textContent = p.points; const list = $('attr-list'); list.innerHTML = '';
    const names = { ataque: 'Ataque', velocidade: 'Velocidade de ataque', defesa: 'Defesa' };
    for (const k of Object.keys(names)) { const r = document.createElement('div'); r.className = 'attr-row'; r.innerHTML = `<span>${names[k]} <b>${p.attr[k]}</b></span>`; const b = document.createElement('button'); b.textContent = '+'; b.disabled = p.points <= 0; b.onclick = () => { p.spend(k); this.refreshPanels(); }; r.appendChild(b); list.appendChild(r); }
    $('attr-derived').innerHTML = `Dano por golpe: <b>${p.damage}</b> · Golpes por segundo: <b>${(1 / p.swingTime).toFixed(1)}</b> · Defesa total: <b>${p.defense}</b> · Vida máxima: <b>${p.maxHp}</b><br>Abates: ${p.stats.kills || 0} · Nível ${p.level}, faltam ${p.xpToNext() - p.xp} XP`;
  }
}
