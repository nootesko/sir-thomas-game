# Épico — A Fortaleza do Relâmpago Amarelo

Registro único de tudo que foi pedido, decidido e feito. Atualizado em 12/10/2026. Detalhes de sistemas em `docs/design.md`; o reino inteiro em `docs/mundo.md`.

## Visão do produto

RPG de ação pixel art, vista de cima estilo Tibia, para público infantil com história rica (Sir Thomas, Princesa Maite, Mordrak). A cidade deve parecer viva e cheia de detalhes mesmo antes de o mundo inteiro existir. O jogador caça, ganha XP e moedas, distribui atributos, compra e equipa, conversa com personagens que reagem às escolhas e cumpre missões.

## Linha do tempo das decisões

| Data | Decisão |
|---|---|
| 11/10 | Protótipo 3D rejeitado; a referência visual é 2D pixel art com mãos na tela. |
| 12/10 manhã | Versão 2.5D em primeira pessoa (Three.js + sprites). Minimapa com clique abre o mapa inteiro. |
| 12/10 | Primeira pessoa "não está funcionando": câmera fixa de cima estilo Tibia, Thomas visível, clique ataca. |
| 12/10 | Imagens v1 "mal desenhadas": nova leva (v2) com prompts de pixel art limpa; sprites reduzidos a grade real de pixels ao carregar. |
| 12/10 | Monstros (coelho, lobo, abelha, serpente, rato, barata), XP e atributos, drops, inventário, comércio, comida e poções, esgoto. |
| 12/10 | Documento "O mundo de Sr. Thomas" recebido e guardado (Malace, Lossot, Neveo, Desfiladeiro da Caveira, Castelo de Geleca, Rei Pássaro). Só o protótipo por enquanto. |
| 12/10 | Avaliado trocar para o Intersect Engine (C#, editor só Windows); o usuário pediu para esperar. |
| 12/10 | Cidade maior (muralha 90, portão sul, Castelo Real, Jardins, Campo de Treino, Hortas), telhados transparentes perto do Thomas, ícone "$" dos vendedores nos mapas, render em resolução cheia, leva v3 de imagens em qualidade alta. |
| 12/10 | Pesquisa de projetos abertos (clientes Open Tibia em JS, RPG JS). Recomendação aceita: manter o código, trocar o cenário para tiles. |
| 12/10 | Mundo em tiles com transições de borda; movimento livre e suave com clique para andar (A*) e clique no monstro para perseguir e atacar; tecla F golpeia. |

## Pedidos ainda abertos (ordem sugerida)

1. **Diálogos com escolhas** que mudam flags da história, textos menos bobos, side quests com log, "!" no mapa.
2. **Combate mais rico**: críticos, números de dano flutuantes, drops raros, monstro alfa.
3. **Relógio do dia**: horas, transição dia/entardecer/noite, lampiões acendem; NPCs com rotina (trabalhar, comprar nas barracas, voltar para casa e dormir à noite); ruas cheias.
4. **Casas com interior e portas**: entrar nas casas, portas abrem com E, algumas trancadas; **lockpick** estilo Skyrim (minigame de ângulo com gazua que pode quebrar); histórias das casas (diários, baús, donos com nome).
5. **Cavernas**: masmorra de rocha com entrada na cidade (reaproveitando o sistema do esgoto), monstros novos (morcego, aranha).
6. **Profundidade nos objetos**: arte em vista 3/4 de cima (vemos o topo das copas e dos objetos), sprites desenhados deitados no chão com ordem de pintura, sombras no chão; **sprite sheets** por personagem com 4 direções e passos de caminhada.
7. Mundo completo de `docs/mundo.md` e capítulos III em diante.

## Perguntas respondidas

- **Hexágonos em vez de tiles?** Não recomendado. A movimentação já é livre (qualquer ângulo, sem travar na grade), então a grade só serve para o chão e para o caminho do clique; hexágonos não encaixam com casas, muralhas e ruas retas, e nenhum editor ou tileset padrão usa hexágonos para esse gênero.
- **Por que a árvore parece papel?** Porque a arte é vista de frente e inclinada para a câmera. A solução é arte 3/4 de cima deitada no chão (item 6).

## Referências

- Intersect Engine (sistemas): https://github.com/AscensionGameDev/Intersect-Engine
- RPG JS (framework alternativo, MIT): https://github.com/RSamaium/RPG-JS
- Clientes Open Tibia em JS (só inspiração, dependem de sprites da CipSoft): Tibia74-JS-Engine, TibiaJS, otclient-web, otcts
- Tileset livre CC0: Tiny Top Down Pack (opengameart)

## Arte e custos

- Prompts: `tools/briefing-v2.html` (v2), `tools/briefing-v3.html` (v3, qualidade alta), `tools/briefing-sheets.html` (sprite sheets 3/4). Gerador: `tools/gen-assets.mjs` (OpenAI gpt-image-1).
- Versões anteriores em `assets_v1/` e `assets_v2/`. Cada leva completa custa por volta de 6 a 12 dólares.
